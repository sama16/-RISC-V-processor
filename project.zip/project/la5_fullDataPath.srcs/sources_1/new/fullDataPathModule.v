`timescale 1ns / 1ps

module fullDataPathModule(
    input clk,
    input rst,
    input [1:0] ledSel,
    input [3:0] ssdSel,
    output reg [15:0] leds,
    output reg [12:0] ssd
);

    wire [31:0] PC;
    reg  [31:0] PC_next;
    wire [31:0] PC_plus4;
    wire [31:0] BranchTarget;

    assign PC_plus4 = PC + 32'd4;

    wire [31:0] Instruction;

    instructionMemory instruction_memory(
        .addr(PC[7:2]),
        .data_out(Instruction)
    );

    // The five special instructions (decoded explicitly):
    //   EBREAK     0x00100073        -> halts: the PC register stops loading
    //   ECALL      0x00000073        -> no-operation (ControlUnit raises no signal)
    //   FENCE      opcode 0001111    -> no-operation
    //   PAUSE      (FENCE encoding)  -> no-operation
    //   FENCE.TSO  (FENCE encoding)  -> no-operation
    wire is_ebreak;
    assign is_ebreak = (Instruction == 32'h00100073);

    wire halt;
    assign halt = is_ebreak;

    wire Branch, Jump, JumpReg;
    wire MemRead, MemWrite;
    wire ALUSrc, RegWrite;
    wire [1:0] ASel, WBSel;

    ControlUnit controlUnit(
        .opcode(Instruction[6:0]),
        .Branch(Branch),
        .Jump(Jump),
        .JumpReg(JumpReg),
        .MemRead(MemRead),
        .MemWrite(MemWrite),
        .ALUSrc(ALUSrc),
        .RegWrite(RegWrite),
        .ASel(ASel),
        .WBSel(WBSel)
    );

    wire [31:0] ReadData1;
    wire [31:0] ReadData2;
    reg  [31:0] WriteBackData;

    RegFile regFile(
        .clk(clk),
        .rst(rst),
        .readreg1(Instruction[19:15]),
        .readreg2(Instruction[24:20]),
        .writereg(Instruction[11:7]),
        .writedata(WriteBackData),
        .regwrite(RegWrite),
        .readdata1(ReadData1),
        .readdata2(ReadData2)
    );

    wire [31:0] Immediate;

    ImmGen immGen1(
        .inst(Instruction),
        .gen_out(Immediate)
    );

    // Kept only for SSD monitoring. ImmGen already produces the
    // x2-scaled B/J offsets, so this is NOT used in the branch target.
    wire [31:0] ShiftedImmediate;

    N_bit_shift_left shift_left(
        .in(Immediate),
        .out(ShiftedImmediate)
    );

    // ALU operand muxes
    reg [31:0] ALUInput1;
    always @(*) begin
        case (ASel)
            2'd1:    ALUInput1 = PC;          // AUIPC
            2'd2:    ALUInput1 = 32'b0;       // LUI
            default: ALUInput1 = ReadData1;
        endcase
    end

    wire [31:0] ALUInput2;
    assign ALUInput2 = ALUSrc ? Immediate : ReadData2;

    wire [3:0] ALUSel;

    ALUControl aluControl(
        .opcode(Instruction[6:0]),
        .funct3(Instruction[14:12]),
        .funct7(Instruction[31:25]),
        .ALUSel(ALUSel)
    );

    wire [31:0] ALUResult;
    wire Zero;

    ALU alu(
        .in1(ALUInput1),
        .in2(ALUInput2),
        .aluSel(ALUSel),
        .result(ALUResult),
        .Zero(Zero)
    );

    // Branch comparison (all six branch types)
    wire eq  = (ReadData1 == ReadData2);
    wire lt  = ($signed(ReadData1) < $signed(ReadData2));
    wire ltu = (ReadData1 < ReadData2);

    reg BranchCond;
    always @(*) begin
        case (Instruction[14:12])
            3'b000:  BranchCond = eq;     // BEQ
            3'b001:  BranchCond = ~eq;    // BNE
            3'b100:  BranchCond = lt;     // BLT
            3'b101:  BranchCond = ~lt;    // BGE
            3'b110:  BranchCond = ltu;    // BLTU
            3'b111:  BranchCond = ~ltu;   // BGEU
            default: BranchCond = 1'b0;
        endcase
    end

    wire BranchTaken;
    assign BranchTaken = Branch & BranchCond;

    wire [31:0] DataMemoryOut;

    DataMem dataMemory(
        .clk(clk),
        .MemRead(MemRead),
        .MemWrite(MemWrite),
        .funct3(Instruction[14:12]),
        .addr(ALUResult[7:0]),
        .data_in(ReadData2),
        .data_out(DataMemoryOut)
    );

    // Write-back mux
    always @(*) begin
        case (WBSel)
            2'd1:    WriteBackData = DataMemoryOut;
            2'd2:    WriteBackData = PC_plus4;     // JAL / JALR link
            default: WriteBackData = ALUResult;
        endcase
    end

    // Next PC
    assign BranchTarget = PC + Immediate;          // branches and JAL

    always @(*) begin
        if (JumpReg)
            PC_next = {ALUResult[31:1], 1'b0};     // JALR: (rs1+imm) & ~1
        else if (Jump | BranchTaken)
            PC_next = BranchTarget;
        else
            PC_next = PC_plus4;
    end

    N_bitRegister PC_register(
        .clk(clk),
        .rst(rst),
        .load(~halt),
        .D(PC_next),
        .Q(PC)
    );

    // LED monitoring
    always @(*) begin
        case (ledSel)
            2'b00: leds = Instruction[15:0];
            2'b01: leds = Instruction[31:16];
            2'b10: leds = {
                halt,
                Jump,
                JumpReg,
                ALUSel,
                Zero,
                BranchTaken,
                Branch,
                MemRead,
                MemWrite,
                RegWrite,
                WBSel,
                ALUSrc
            };
            default: leds = 16'b0;
        endcase
    end

    // SSD monitoring
    always @(*) begin
        case (ssdSel)
            4'b0000: ssd = PC[12:0];
            4'b0001: ssd = PC_plus4[12:0];
            4'b0010: ssd = BranchTarget[12:0];
            4'b0011: ssd = PC_next[12:0];
            4'b0100: ssd = ReadData1[12:0];
            4'b0101: ssd = ReadData2[12:0];
            4'b0110: ssd = WriteBackData[12:0];
            4'b0111: ssd = Immediate[12:0];
            4'b1000: ssd = ShiftedImmediate[12:0];
            4'b1001: ssd = ALUInput2[12:0];
            4'b1010: ssd = ALUResult[12:0];
            4'b1011: ssd = DataMemoryOut[12:0];
            default: ssd = 13'b0;
        endcase
    end

endmodule