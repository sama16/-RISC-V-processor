module top_datapath_sevenSegement(
    input rclk,
    input rst,
    input clk,
    input [1:0] ledSel,
    input [3:0] ssdSel,
    output [15:0] leds,
    output [6:0] LED_out,
    output [3:0] Anode
);

    wire [12:0] ssd_data;

fullDataPathModule processor(
        .clk(rclk),
        .rst(rst),
        .ledSel(ledSel),
        .ssdSel(ssdSel),
        .leds(leds),
        .ssd(ssd_data)
    );

Four_Digit_Seven_Segment_Driver_Optimized display(
        .clk(clk),
        .num(ssd_data),
        .Anode(Anode),
        .LED_out(LED_out)
    );

endmodule