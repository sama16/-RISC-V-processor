`timescale 1ns / 1ps

module fullDataPath_tb;
    reg clk = 0;
    reg rst = 1;
    reg [1:0] ledSel = 0;
    reg [3:0] ssdSel = 0;
    wire [15:0] leds;
    wire [12:0] ssd;

    fullDataPathModule dut (
        .clk(clk), .rst(rst), .ledSel(ledSel), .ssdSel(ssdSel),
        .leds(leds), .ssd(ssd)
    );

    always #5 clk = ~clk;

    reg [31:0] expected_reg [0:31];
    reg known_reg [0:31];
    reg [7:0] expected_mem [0:255];
    reg known_mem [0:255];
    reg [31:0] expected_pc;
    reg [31:0] instr, a, b, result, next_pc;
    reg [31:0] imm_i, imm_s, imm_b, imm_u, imm_j;
    reg [31:0] address, loaded;
    reg source_known, result_known, take_branch;
    reg [4:0] rd, rs1, rs2;
    reg [6:0] opcode;
    reg [2:0] funct3;
    reg [6:0] funct7;
    integer errors, steps, r, m, n, size;
    reg finished;

    task fail_pc;
        input [31:0] expected;
        begin
            $display("FAIL step %0d: PC expected %h, got %h", steps, expected, dut.PC);
            errors = errors + 1;
        end
    endtask

    initial begin
        errors = 0;
        steps = 0;
        finished = 0;
        expected_pc = 0;
        for (r = 0; r < 32; r = r + 1) begin
            expected_reg[r] = 0;
            known_reg[r] = 1;
        end
        for (m = 0; m < 256; m = m + 1) begin
            expected_mem[m] = 0;
            known_mem[m] = 0;
        end

        repeat (3) @(posedge clk);
        #1;
        if (dut.PC !== 0) begin
            $display("FAIL: reset PC = %h", dut.PC);
            errors = errors + 1;
        end else $display("PASS: reset PC = 0");
        @(negedge clk);
        rst = 0;

        while (!finished && steps < 120) begin
            instr = dut.instruction_memory.mem[expected_pc[7:2]];
            opcode = instr[6:0];
            rd = instr[11:7];
            funct3 = instr[14:12];
            rs1 = instr[19:15];
            rs2 = instr[24:20];
            funct7 = instr[31:25];
            a = expected_reg[rs1];
            b = expected_reg[rs2];
            imm_i = {{20{instr[31]}}, instr[31:20]};
            imm_s = {{20{instr[31]}}, instr[31:25], instr[11:7]};
            imm_b = {{19{instr[31]}}, instr[31], instr[7], instr[30:25], instr[11:8], 1'b0};
            imm_u = {instr[31:12], 12'b0};
            imm_j = {{11{instr[31]}}, instr[31], instr[19:12], instr[20], instr[30:21], 1'b0};
            next_pc = expected_pc + 4;
            result = 0;
            result_known = 1;
            source_known = known_reg[rs1] && known_reg[rs2];
            take_branch = 0;
            address = 0;
            size = 0;

            case (opcode)
                7'b0010011: begin
                    result_known = known_reg[rs1];
                    case (funct3)
                        3'b000: result = a + imm_i;
                        3'b010: result = ($signed(a) < $signed(imm_i));
                        3'b011: result = (a < imm_i);
                        3'b100: result = a ^ imm_i;
                        3'b110: result = a | imm_i;
                        3'b111: result = a & imm_i;
                        3'b001: result = a << instr[24:20];
                        3'b101: result = instr[30] ? ($signed(a) >>> instr[24:20]) : (a >> instr[24:20]);
                    endcase
                end
                7'b0110011: begin
                    result_known = source_known;
                    case (funct3)
                        3'b000: result = instr[30] ? a - b : a + b;
                        3'b001: result = a << b[4:0];
                        3'b010: result = ($signed(a) < $signed(b));
                        3'b011: result = (a < b);
                        3'b100: result = a ^ b;
                        3'b101: result = instr[30] ? ($signed(a) >>> b[4:0]) : (a >> b[4:0]);
                        3'b110: result = a | b;
                        3'b111: result = a & b;
                    endcase
                end
                7'b0110111: result = imm_u;
                7'b0010111: result = expected_pc + imm_u;
                7'b1101111: begin
                    result = expected_pc + 4;
                    next_pc = expected_pc + imm_j;
                end
                7'b1100111: begin
                    result = expected_pc + 4;
                    if (!known_reg[rs1]) begin
                        $display("FAIL: unknown JALR source");
                        errors = errors + 1;
                        finished = 1;
                    end else next_pc = (a + imm_i) & 32'hfffffffe;
                end
                7'b1100011: begin
                    if (!source_known) begin
                        $display("FAIL: unknown branch operand");
                        errors = errors + 1;
                        finished = 1;
                    end else begin
                        case (funct3)
                            3'b000: take_branch = (a == b);
                            3'b001: take_branch = (a != b);
                            3'b100: take_branch = ($signed(a) < $signed(b));
                            3'b101: take_branch = ($signed(a) >= $signed(b));
                            3'b110: take_branch = (a < b);
                            3'b111: take_branch = (a >= b);
                        endcase
                        if (take_branch) next_pc = expected_pc + imm_b;
                    end
                end
                7'b0100011: begin
                    address = a + imm_s;
                    case (funct3)
                        3'b000: size = 1;
                        3'b001: size = 2;
                        3'b010: size = 4;
                        default: size = 0;
                    endcase
                    if (known_reg[rs1] && address + size <= 256) begin
                        for (n = 0; n < size; n = n + 1) begin
                            expected_mem[address+n] = b[n*8 +: 8];
                            known_mem[address+n] = known_reg[rs2];
                        end
                    end else begin
                        $display("FAIL: invalid store address %h", address);
                        errors = errors + 1;
                        finished = 1;
                    end
                end
                7'b0000011: begin
                    address = a + imm_i;
                    case (funct3)
                        3'b000, 3'b100: size = 1;
                        3'b001, 3'b101: size = 2;
                        3'b010: size = 4;
                        default: size = 0;
                    endcase
                    result_known = known_reg[rs1] && (size != 0) && (address + size <= 256);
                    loaded = 0;
                    if (result_known) begin
                        for (n = 0; n < size; n = n + 1) begin
                            loaded[n*8 +: 8] = expected_mem[address+n];
                            if (!known_mem[address+n]) result_known = 0;
                        end
                    end
                    case (funct3)
                        3'b000: result = {{24{loaded[7]}}, loaded[7:0]};
                        3'b001: result = {{16{loaded[15]}}, loaded[15:0]};
                        3'b010: result = loaded;
                        3'b100: result = {24'b0, loaded[7:0]};
                        3'b101: result = {16'b0, loaded[15:0]};
                    endcase
                end
                7'b1110011: begin
                    if (instr == 32'h00100073) begin
                        next_pc = expected_pc;
                        finished = 1;
                    end
                end
            endcase

            if (opcode == 7'b0010011 || opcode == 7'b0110011 ||
                opcode == 7'b0110111 || opcode == 7'b0010111 ||
                opcode == 7'b1101111 || opcode == 7'b1100111 ||
                opcode == 7'b0000011) begin
                if (rd != 0) begin
                    expected_reg[rd] = result;
                    known_reg[rd] = result_known;
                end
            end

            @(posedge clk);
            #1;
            steps = steps + 1;
            if (dut.PC !== next_pc) fail_pc(next_pc);
            for (r = 0; r < 32; r = r + 1) begin
                if (known_reg[r] && dut.regFile.Reg[r] !== expected_reg[r]) begin
                    $display("FAIL step %0d PC=%h x%0d expected %h got %h",
                             steps, expected_pc, r, expected_reg[r], dut.regFile.Reg[r]);
                    errors = errors + 1;
                end
            end
            if (opcode == 7'b0100011 && !finished) begin
                for (n = 0; n < size; n = n + 1) begin
                    if (known_mem[address+n] && dut.dataMemory.mem[address+n] !== expected_mem[address+n]) begin
                        $display("FAIL step %0d memory[%0d] expected %h got %h",
                                 steps, address+n, expected_mem[address+n], dut.dataMemory.mem[address+n]);
                        errors = errors + 1;
                    end
                end
            end
            $display("Step %0d: PC=%0d instruction=%h next_PC=%0d", steps, expected_pc, instr, next_pc);
            expected_pc = next_pc;
            if (!finished) @(negedge clk);
        end

        if (expected_pc !== 32'd252) begin
            $display("FAIL: expected EBREAK at PC=252, reached PC=%0d", expected_pc);
            errors = errors + 1;
        end else begin
            repeat (5) begin
                @(posedge clk);
                #1;
                if (dut.PC !== 32'd252) begin
                    $display("FAIL: PC did not stay at 252");
                    errors = errors + 1;
                end
            end
        end

        $display("====================================");
        $display("Executed instructions: %0d", steps);
        $display("Total errors: %0d", errors);
        if (errors == 0) $display("ALL TESTS PASSED");
        else $display("TESTS FAILED");
        $display("====================================");
        $finish;
    end
endmodule
