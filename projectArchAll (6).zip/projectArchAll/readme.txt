==========================================================================
  CSCE 3301 - Computer Architecture - Fall 2026
  Project 1: femtoRV32 - RISC-V FPGA Implementation and Testing
  Milestone 3 (pipelined processor)
==========================================================================

TEAM
----
  Student 1: Sama Almallak   ID: 900246569   
  Student 2: ______________________   ID: __________
 Student 2: ______________________   ID: __________



--------------------------------------------------------------------------
1. WHAT WE BUILT (in one paragraph)
--------------------------------------------------------------------------
A pipelined RISC-V processor (RV32I, all 42 instructions) written in
Verilog and tested on the Nexys A7-100T board. It uses ONE memory for
both the program and the data. Because that memory has only one port,
the CPU starts a new instruction every 2 clock cycles (CPI = 2), so the
fetch and the load/store never need the memory at the same time.
Data hazards are solved with forwarding, control hazards with a flush.
Bonus: multiply/divide (RV32M) and a random test program generator.


--------------------------------------------------------------------------
2. FOLDERS IN THIS SUBMISSION
--------------------------------------------------------------------------
  readme.txt     this file
  journal/       one journal file per team member
  Verilog/       all Verilog files + the board constraints file (.xdc)
  test/          test programs (.s assembly, .mem hex) and testbenches
simulationOutput/ all the waveforms output 
  report.pdf     the full report (design, schematic, tests, screenshots)


--------------------------------------------------------------------------
3. VERILOG MODULES (simple description)
--------------------------------------------------------------------------
  femtoRV32.v     The whole CPU. Connects everything and holds the
                  pipeline registers (IF/ID, ID/EX, EX/MEM, MEM/WB).
                  Also has the "phase" bit (C0 = fetch uses memory,
                  C1 = load/store uses memory), the flush and the halt.
  Memory.v        The one memory (4 KB) for program AND data. Byte

                  addressable, made of 4 byte "banks". The board program
                  is written inside it (PROGRAM_BEGIN ... PROGRAM_END).

  ControlUnit.v   Looks at the opcode and turns on the right control
                  signals (write register? read memory? jump? ...).
                  Unknown/special opcodes give all zeros = do nothing.

  ALUControl.v    Decides which operation the ALU does (add, sub, and,
                  shift, ..., and the 8 multiply/divide operations).

  ALU.v           Does the math: + - and or xor shifts compare,
                  and MUL/MULH/MULHSU/MULHU/DIV/DIVU/REM/REMU.

  ImmGen.v        Builds the immediate (constant) from the instruction
                  bits for each instruction format.

  RegFile.v       The 32 registers (x0 is always 0). 2 read ports for
                  the CPU + 1 extra read port for debugging (board/test).

  ForwardingUnit.v  Detects data hazards: if an instruction needs a
                  register that is not saved yet, it passes the new
                  value straight to the ALU (forwardA / forwardB).
  BranchUnit.v    Decides if a branch is taken (BEQ BNE BLT BGE BLTU BGEU).

  N_bitRegister.v A register of any width with load and reset
                  (used for PC and the pipeline registers).

  DFlipFlop.v     A single flip-flop (used for phase and halted).

  multiplexer2to1.v, decoder5x32.v   small helper parts from the labs.

  Top.v           Connects the CPU to the board: switches, LEDs,
                  7-segment display, manual/automatic clock.

  Debouncer.v     Cleans the switch signal used as a manual clock.

  Four_Digit_Seven_Segment_Driver_Optimized.v
                  Shows a number (decimal) on the 7-segment display.
  NexysA7.xdc     Pin constraints for the board.


--------------------------------------------------------------------------
4. WHAT WORKS
--------------------------------------------------------------------------
  [OK] All 42 RV32I instructions:
       R-type   ADD SUB SLL SLT SLTU XOR SRL SRA OR AND
       I-type   ADDI SLTI SLTIU XORI ORI ANDI SLLI SRLI SRAI
       Loads    LB LH LW LBU LHU
       Stores   SB SH SW
       Branches BEQ BNE BLT BGE BLTU BGEU
       U-type   LUI AUIPC
       Jumps    JAL JALR
       Special  ECALL FENCE FENCE.TSO PAUSE (do nothing = no-op)
                EBREAK (stops the program: the PC freezes)
  [OK] Pipeline with one single-ported memory, one instruction every
       2 cycles (CPI = 2), checked by counting cycles.
  [OK] Data hazards (forwarding, including load-use with no stall).
  [OK] Control hazards (flush of the wrong instruction after a taken
       branch/jump; a wrong-path EBREAK does not stop the CPU).
  [OK] Structural hazard (fetch and load/store never use the memory in
       the same cycle).
  [OK] BONUS 1 - RV32M: MUL MULH MULHSU MULHU DIV DIVU REM REMU,
       including divide by zero and overflow as in the specification.
  [OK] BONUS 2 - random test program generator (Python): makes random
       valid programs (assembly + machine code + expected results).
  [OK] Board: tested ADD, BEQ (taken + flush), SW and LW on the Nexys A7.

  Test results (simulation, all PASS, 0 FAIL):
     type1 R-type 11 | type2 I-type 11 | type3 loads 10 | type4 stores 11
     type5 branches 8 | type6 U-type 5 | type7 jumps 10 | type8 special 7
     type9 RV32M 13 | hazard1 data 18 | hazard2 control 10
     hazard3 structural 12 | random programs (4 seeds) 32-35 each


--------------------------------------------------------------------------
5. WHAT DOES NOT WORK / LIMITATIONS
--------------------------------------------------------------------------
  - No known failing instruction.
  - Misaligned loads/stores (e.g. LW at an address that is not a
    multiple of 4) were not tested; our programs always use aligned
    addresses.
  - ECALL, FENCE, FENCE.TSO and PAUSE do nothing (as the project asks);
    there are no exceptions or interrupts.
  - The CPU is slower than a normal 5-stage pipeline because of the
    single memory (CPI = 2, and a taken branch costs 2 extra cycles).
  - Compressed instructions (RV32C) and branch prediction were not
    done (not required).

--------------------------------------------------------------------------
6. ASSUMPTIONS
--------------------------------------------------------------------------
  - Memory is 4 KB: program at 0x000 - 0x3FF, data from 0x400.
  - The program starts at address 0 after reset.
  - For simulation, each testbench loads its program from a .mem file
    (one 32-bit instruction per line, in hex) with $readmemh.
    IMPORTANT: put the full path of the .mem file in the testbench
    (e.g. "C:/femto/test/type1_rtype.mem"), otherwise Vivado cannot
    find it and all registers stay 0.
  - For the board, the program is written inside Memory.v
    (between PROGRAM_BEGIN and PROGRAM_END) and the bitstream is
    generated again for each new program.
  - The 7-segment display shows the low 13 bits of a value in decimal.


--------------------------------------------------------------------------
7. HOW TO RUN
--------------------------------------------------------------------------
  Simulation (Vivado):
    1. Add all files of Verilog/ as design sources.
    2. Add a testbench (e.g. test/tb_type1_rtype.v) and its .mem file
       as simulation sources, and fix the path inside the testbench.
    3. Tcl console:
         set_property top tb_type1_rtype [get_filesets sim_1]
         launch_simulation
         run all
    4. The console prints PASS/FAIL per instruction and a RESULT line.

  Board:
    Top module = Top. Generate bitstream, program the device.
    SW15 up = automatic clock (SW14 = speed), SW15 down = manual clock
    (flip SW0 = one cycle). SW1 = reset.
    SW7-SW4 choose the display: 0000 PC, 1001 ALU result,
    1100 register x[SW12-SW8], 1101 cycle counter, ...
    SW3-SW2 choose the LEDs: 00/01 instruction bits, 10 status
    (LED15 phase, LED14 halted, LED13 flush, LED12-9 forwarding, ...).


--------------------------------------------------------------------------
8. ISSUES WE HAD AND HOW WE SOLVED THEM
--------------------------------------------------------------------------
  - THE BIGGEST CHALLENGE WAS TESTING AND TRACING. Reading a pipelined
    waveform is hard: 5 instructions are in the CPU at the same time,
    and a bubble sits between every two. We solved it by writing
    testbenches that print PASS/FAIL for each instruction, by adding
    named signals (instruction name in ASCII, ALU inputs/result,
    register written) to the waveform, and by comparing with expected
    waveforms. On the board we used the manual clock to step one
    cycle at a time and checked the display and LEDs at each step.
  - The first memory (one big array) used about 180,000 LUTs and the
    bitstream failed. We rewrote it as 4 byte banks so Vivado uses
    small RAM blocks.
  - Vivado could not find the program file ($readmemh path problems).
    For the board we put the program inside Memory.v; for simulation
    we use the full path of the .mem file.
  - A wrong-path EBREAK (fetched right after a taken branch) set the
    "halted" flag too early. Fixed by only accepting an EBREAK that is
    not flushed.
  - The constraints file did not match the top module ports, so the
    bitstream failed (unconstrained ports). Fixed by adding the
    missing pins.
  - Vivado sometimes locked simulate.log ("used by another process").
    Fixed by closing the simulation / ending xsimk.exe before running
    a new one.
==========================================================================
