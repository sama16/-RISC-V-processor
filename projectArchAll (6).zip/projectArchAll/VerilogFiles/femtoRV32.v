`timescale 1ns / 1ps


module femtoRV32 #(
    parameter MEM_INIT = ""
) (
    input             clk,
    input             rst,
    input      [1:0]  ledSel,
    input      [3:0]  ssdSel,
    input      [4:0]  dbgReg,
    output reg [15:0] leds,
    output reg [12:0] ssd,
    output            halted
);

    localparam [31:0] NOP    = 32'h00000013;   // addi x0, x0, 0
    localparam [31:0] EBREAK = 32'h00100073;

    // We have only ONE memory for instructions AND data, so the CPU takes turns:
    //   phase = 0 (C0) : the memory is used to FETCH the next instruction
    //   phase = 1 (C1) :the memory is used by a LOAD or STORE
    // phase simply flips 0, 1, 0, 1 ... every clock cycle. Because of this, a new instruction starts every 2 cycles (CPI = 2).
    wire phase;
    DFlipFlop phase_ff (
        .clk(clk), .rst(rst), .D(~phase), .Q(phase)
    );

    wire fetch = ~phase;                       // C0: memory for  IF

    // Forward  signals 
    wire [31:0] PC;
    wire        EX_MEM_PCSrc;
    wire [31:0] EX_MEM_Target;
    wire [31:0] EX_MEM_ALUResult;
    wire [31:0] EX_MEM_StoreData;
    wire [2:0]  EX_MEM_funct3;
    wire        EX_MEM_MemRead;
    wire        EX_MEM_MemWrite;

    wire [31:0] mem_addr   = fetch ? PC     : EX_MEM_ALUResult;     // address: in C0 read the instruction at PC, in C1 use the address computed by the load/store (ALU result)
    wire  mem_read   = fetch ? 1'b1   : EX_MEM_MemRead;     // read: in C0 always read (we need the instruction), in C1 read only if the instruction is a load
    wire mem_write  = fetch ? 1'b0   : EX_MEM_MemWrite;  // write: in C0 never write (fetching never changes memory),in C1 write only if the instruction is a store
    wire [2:0]  mem_funct3 = fetch ? 3'b010 : EX_MEM_funct3; //  size: in C0 read a whole word (instructions are 32 bits = 010), in C1 use the load/store size (byte, half or word from funct3)
    wire [31:0] mem_out; // what the memory gives back: an instruction in C0, load data in C1

    Memory #(.ADDR_BITS(12), .INIT_FILE(MEM_INIT)) memory (
        .clk(clk),
        .MemRead(mem_read),
        .MemWrite(mem_write),
        .funct3(mem_funct3),
        .addr(mem_addr[11:0]),
        .data_in(EX_MEM_StoreData),
        .data_out(mem_out)
    );

    
    // IF stage
   
    wire [31:0] PC_plus4 = PC + 32'd4;

    wire redirect    = phase & EX_MEM_PCSrc;            // taken branch / jump in MEM
    wire halt        = fetch & (mem_out == EBREAK);     // EBREAK fetched
    wire PC_load     = redirect | (fetch & ~halt);
    wire [31:0] PC_next = redirect ? EX_MEM_Target : PC_plus4;

    N_bitRegister #(32) PC_reg (
        .clk(clk), .rst(rst), .load(PC_load), .D(PC_next), .Q(PC)
    );

   // halted = 1 when the program stops at EBREAK, and stays 1 until reset. (Used for LED14, the testbench, and to stop the cycle counter.)
    wire halt_commit;                 // 1 = a real EBREAK (not one that gets flushed)
    wire halt_commit;
    DFlipFlop halted_ff (
        .clk(clk), .rst(rst), .D(halted | halt_commit), .Q(halted)
    );

    // ---------------- IF/ID ----------------
    wire [31:0] IF_ID_PC, IF_ID_Inst;
    N_bitRegister #(64) IF_ID (
        .clk(clk), .rst(rst), .load(1'b1),
        .D(fetch ? {PC, mem_out} : {32'b0, NOP}),
        .Q({IF_ID_PC, IF_ID_Inst})
    );

    // ID stage
    wire       Branch, Jump, JumpReg, MemRead, MemWrite, ALUSrc, RegWrite;
    wire [1:0] ASel, WBSel;

    ControlUnit control_unit (
        .opcode(IF_ID_Inst[6:0]),
        .Branch(Branch), .Jump(Jump), .JumpReg(JumpReg),
        .MemRead(MemRead), .MemWrite(MemWrite),
        .ALUSrc(ALUSrc), .RegWrite(RegWrite),
        .ASel(ASel), .WBSel(WBSel)
    );

    wire [4:0] ALUSel;
    ALUControl alu_control (
        .opcode(IF_ID_Inst[6:0]),
        .funct3(IF_ID_Inst[14:12]),
        .funct7(IF_ID_Inst[31:25]),
        .ALUSel(ALUSel)
    );

    wire [31:0] Immediate;
    ImmGen imm_gen (
        .inst(IF_ID_Inst), .gen_out(Immediate)
    );

    // Write-back signals (from WB stage)
    wire [4:0]  MEM_WB_rd;
    wire        MEM_WB_RegWrite;
    reg  [31:0] WriteBackData;

    wire [31:0] ReadData1, ReadData2, DebugRegData;
    RegFile reg_file (
        .clk(clk), .rst(rst),
        .readreg1(IF_ID_Inst[19:15]),
        .readreg2(IF_ID_Inst[24:20]),
        .readreg3(dbgReg),
        .writereg(MEM_WB_rd),
        .writedata(WriteBackData),
        .regwrite(MEM_WB_RegWrite),
        .readdata1(ReadData1),
        .readdata2(ReadData2),
        .readdata3(DebugRegData)
    );

    assign halt_commit = phase & (IF_ID_Inst == EBREAK) & ~redirect;

    // ---------------- ID/EX ----------------
    wire [10:0] ID_ctrl = {Branch, Jump, JumpReg, MemRead, MemWrite,
                           ALUSrc, RegWrite, ASel, WBSel};

    wire [31:0] ID_EX_PC, ID_EX_RD1, ID_EX_RD2, ID_EX_Imm, ID_EX_Inst;
    wire [4:0]  ID_EX_rs1, ID_EX_rs2, ID_EX_rd, ID_EX_ALUSel;
    wire [2:0]  ID_EX_funct3;
    wire [10:0] ID_EX_ctrl;

    N_bitRegister #(194) ID_EX (
        .clk(clk), .rst(rst), .load(1'b1),
        .D(redirect ? 194'b0 :
           {IF_ID_PC, ReadData1, ReadData2, Immediate, IF_ID_Inst,
            IF_ID_Inst[19:15], IF_ID_Inst[24:20], IF_ID_Inst[11:7],
            IF_ID_Inst[14:12], ALUSel, ID_ctrl}),
        .Q({ID_EX_PC, ID_EX_RD1, ID_EX_RD2, ID_EX_Imm, ID_EX_Inst,
            ID_EX_rs1, ID_EX_rs2, ID_EX_rd,
            ID_EX_funct3, ID_EX_ALUSel, ID_EX_ctrl})
    );

    wire       ID_EX_Branch, ID_EX_Jump, ID_EX_JumpReg, ID_EX_MemRead,
               ID_EX_MemWrite, ID_EX_ALUSrc, ID_EX_RegWrite;
    wire [1:0] ID_EX_ASel, ID_EX_WBSel;
    assign {ID_EX_Branch, ID_EX_Jump, ID_EX_JumpReg, ID_EX_MemRead,
            ID_EX_MemWrite, ID_EX_ALUSrc, ID_EX_RegWrite,
            ID_EX_ASel, ID_EX_WBSel} = ID_EX_ctrl;

    // EX stage
    wire [4:0]  EX_MEM_rd;
    wire        EX_MEM_RegWrite;
    wire [1:0]  EX_MEM_WBSel;
    wire [31:0] EX_MEM_PCplus4;
    wire [1:0]  forwardA, forwardB;

    // [STEP 3] forwarding unit
    ForwardingUnit forwarding_unit (
        .ID_EX_rs1(ID_EX_rs1),
        .ID_EX_rs2(ID_EX_rs2),
        .EX_MEM_rd(EX_MEM_rd),
        .EX_MEM_RegWrite(EX_MEM_RegWrite),
        .EX_MEM_MemRead(EX_MEM_MemRead),
        .MEM_WB_rd(MEM_WB_rd),
        .MEM_WB_RegWrite(MEM_WB_RegWrite),
        .forwardA(forwardA),
        .forwardB(forwardB)
    );

    // Value an instruction in MEM will write back (for EX/MEM forwarding)
    wire [31:0] EX_MEM_FwdValue = (EX_MEM_WBSel == 2'd2) ? EX_MEM_PCplus4
                                                         : EX_MEM_ALUResult;

    reg [31:0] FwdA, FwdB;
    always @(*) begin
        case (forwardA)
            2'b10:   FwdA = EX_MEM_FwdValue;
            2'b01:   FwdA = WriteBackData;
            default: FwdA = ID_EX_RD1;
        endcase
        case (forwardB)
            2'b10:   FwdB = EX_MEM_FwdValue;
            2'b01:   FwdB = WriteBackData;
            default: FwdB = ID_EX_RD2;
        endcase
    end

    reg [31:0] ALUInput1;
    always @(*) begin
        case (ID_EX_ASel)
            2'd1:    ALUInput1 = ID_EX_PC;     // AUIPC
            2'd2:    ALUInput1 = 32'b0;        // LUI
            default: ALUInput1 = FwdA;
        endcase
    end

    wire [31:0] ALUInput2 = ID_EX_ALUSrc ? ID_EX_Imm : FwdB;

    wire [31:0] ALUResult;
    wire        Zero;
    ALU alu (
        .in1(ALUInput1), .in2(ALUInput2), .aluSel(ID_EX_ALUSel),
        .result(ALUResult), .Zero(Zero)
    );

    wire BranchCond;
    BranchUnit branch_unit (
        .funct3(ID_EX_funct3), .a(FwdA), .b(FwdB), .cond(BranchCond)
    );

    wire        EX_PCSrc  = ID_EX_Jump | ID_EX_JumpReg | (ID_EX_Branch & BranchCond);
    wire [31:0] EX_Target = ID_EX_JumpReg ? {ALUResult[31:1], 1'b0}   // JALR
                                          : (ID_EX_PC + ID_EX_Imm);   // branch / JAL
    wire [31:0] EX_PCplus4 = ID_EX_PC + 32'd4;

    // ---------------- EX/MEM ----------------
    wire [31:0] EX_MEM_Inst;
    N_bitRegister #(174) EX_MEM (
        .clk(clk), .rst(rst), .load(1'b1),
        .D({EX_PCSrc, EX_Target, ALUResult, FwdB, EX_PCplus4, ID_EX_Inst,
            ID_EX_rd, ID_EX_funct3, ID_EX_MemRead, ID_EX_MemWrite,
            ID_EX_RegWrite, ID_EX_WBSel}),
        .Q({EX_MEM_PCSrc, EX_MEM_Target, EX_MEM_ALUResult, EX_MEM_StoreData,
            EX_MEM_PCplus4, EX_MEM_Inst, EX_MEM_rd, EX_MEM_funct3,
            EX_MEM_MemRead, EX_MEM_MemWrite, EX_MEM_RegWrite, EX_MEM_WBSel})
    );

    // MEM stage (memory access happens in the C1 cycle - see memory mux)
    wire [31:0] MEM_WB_MemData, MEM_WB_ALUResult, MEM_WB_PCplus4, MEM_WB_Inst;
    wire [1:0]  MEM_WB_WBSel;

    N_bitRegister #(136) MEM_WB (
        .clk(clk), .rst(rst), .load(1'b1),
        .D({mem_out, EX_MEM_ALUResult, EX_MEM_PCplus4, EX_MEM_Inst,
            EX_MEM_rd, EX_MEM_RegWrite, EX_MEM_WBSel}),
        .Q({MEM_WB_MemData, MEM_WB_ALUResult, MEM_WB_PCplus4, MEM_WB_Inst,
            MEM_WB_rd, MEM_WB_RegWrite, MEM_WB_WBSel})
    );

    // WB stage
    always @(*) begin
        case (MEM_WB_WBSel)
            2'd1:    WriteBackData = MEM_WB_MemData;
            2'd2:    WriteBackData = MEM_WB_PCplus4;     // JAL / JALR link
            default: WriteBackData = MEM_WB_ALUResult;
        endcase
    end

    // Cycle counter (stops when the CPU is halted) - for monitoring / CPI
    wire [31:0] cycle_count;
    N_bitRegister #(32) cycle_counter (
        .clk(clk), .rst(rst), .load(~halted),
        .D(cycle_count + 32'd1), .Q(cycle_count)
    );

    // LED 
    always @(*) begin
        case (ledSel)
            2'b00: leds = IF_ID_Inst[15:0];
            2'b01: leds = IF_ID_Inst[31:16];
            2'b10: leds = {phase, halted, redirect, forwardA, forwardB,
                           Branch, Jump, JumpReg, MemRead, MemWrite,
                           ALUSrc, RegWrite, WBSel};
            2'b11: leds = {ID_EX_rd, EX_MEM_rd, MEM_WB_rd, MEM_WB_RegWrite};
            default: leds = 16'b0;
        endcase
    end

    // Seven-segment 
    always @(*) begin
        case (ssdSel)
            4'b0000: ssd = PC[12:0];
            4'b0001: ssd = IF_ID_PC[12:0];
            4'b0010: ssd = ID_EX_PC[12:0];
            4'b0011: ssd = EX_MEM_Target[12:0];
            4'b0100: ssd = ReadData1[12:0];
            4'b0101: ssd = ReadData2[12:0];
            4'b0110: ssd = Immediate[12:0];
            4'b0111: ssd = ALUInput1[12:0];
            4'b1000: ssd = ALUInput2[12:0];
            4'b1001: ssd = ALUResult[12:0];
            4'b1010: ssd = mem_out[12:0];
            4'b1011: ssd = WriteBackData[12:0];
            4'b1100: ssd = DebugRegData[12:0];
            4'b1101: ssd = cycle_count[12:0];
            4'b1110: ssd = EX_MEM_ALUResult[12:0];
            default: ssd = 13'b0;
        endcase
    end

endmodule