`timescale 1ns / 1ps


module Debouncer #(parameter CNT_BITS = 20) (
    input      clk,
    input      btn_in,
    output reg btn_out
);

    reg                sync0 = 1'b0;
    reg                sync1 = 1'b0;
    reg [CNT_BITS-1:0] count = {CNT_BITS{1'b0}};

    initial btn_out = 1'b0;

    always @(posedge clk) begin
        sync0 <= btn_in;            // two-flop synchroniser
        sync1 <= sync0;

        if (sync1 == btn_out)
            count <= {CNT_BITS{1'b0}};
        else begin
            count <= count + 1'b1;
            if (&count)
                btn_out <= sync1;
        end
    end

endmodule
