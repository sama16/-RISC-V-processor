
set_property PACKAGE_PIN E3 [get_ports {clk}]
set_property IOSTANDARD LVCMOS33 [get_ports {clk}]
create_clock -period 10.000 -name sys_clk [get_ports {clk}]

set_property PACKAGE_PIN J15 [get_ports {rclk}]
set_property IOSTANDARD LVCMOS33 [get_ports {rclk}]
set_property CLOCK_DEDICATED_ROUTE FALSE [get_nets {rclk}]

set_property PACKAGE_PIN L16 [get_ports {rst}]
set_property IOSTANDARD LVCMOS33 [get_ports {rst}]

set_property PACKAGE_PIN M13 [get_ports {ledSel[0]}]
set_property IOSTANDARD LVCMOS33 [get_ports {ledSel[0]}]

set_property PACKAGE_PIN R15 [get_ports {ledSel[1]}]
set_property IOSTANDARD LVCMOS33 [get_ports {ledSel[1]}]

set_property PACKAGE_PIN R17 [get_ports {ssdSel[0]}]
set_property IOSTANDARD LVCMOS33 [get_ports {ssdSel[0]}]

set_property PACKAGE_PIN T18 [get_ports {ssdSel[1]}]
set_property IOSTANDARD LVCMOS33 [get_ports {ssdSel[1]}]

set_property PACKAGE_PIN U18 [get_ports {ssdSel[2]}]
set_property IOSTANDARD LVCMOS33 [get_ports {ssdSel[2]}]

set_property PACKAGE_PIN R13 [get_ports {ssdSel[3]}]
set_property IOSTANDARD LVCMOS33 [get_ports {ssdSel[3]}]

set_property PACKAGE_PIN H17 [get_ports {leds[0]}]
set_property IOSTANDARD LVCMOS33 [get_ports {leds[0]}]

set_property PACKAGE_PIN K15 [get_ports {leds[1]}]
set_property IOSTANDARD LVCMOS33 [get_ports {leds[1]}]

set_property PACKAGE_PIN J13 [get_ports {leds[2]}]
set_property IOSTANDARD LVCMOS33 [get_ports {leds[2]}]

set_property PACKAGE_PIN N14 [get_ports {leds[3]}]
set_property IOSTANDARD LVCMOS33 [get_ports {leds[3]}]

set_property PACKAGE_PIN R18 [get_ports {leds[4]}]
set_property IOSTANDARD LVCMOS33 [get_ports {leds[4]}]

set_property PACKAGE_PIN V17 [get_ports {leds[5]}]
set_property IOSTANDARD LVCMOS33 [get_ports {leds[5]}]

set_property PACKAGE_PIN U17 [get_ports {leds[6]}]
set_property IOSTANDARD LVCMOS33 [get_ports {leds[6]}]

set_property PACKAGE_PIN U16 [get_ports {leds[7]}]
set_property IOSTANDARD LVCMOS33 [get_ports {leds[7]}]

set_property PACKAGE_PIN V16 [get_ports {leds[8]}]
set_property IOSTANDARD LVCMOS33 [get_ports {leds[8]}]

set_property PACKAGE_PIN T15 [get_ports {leds[9]}]
set_property IOSTANDARD LVCMOS33 [get_ports {leds[9]}]

set_property PACKAGE_PIN U14 [get_ports {leds[10]}]
set_property IOSTANDARD LVCMOS33 [get_ports {leds[10]}]

set_property PACKAGE_PIN T16 [get_ports {leds[11]}]
set_property IOSTANDARD LVCMOS33 [get_ports {leds[11]}]

set_property PACKAGE_PIN V15 [get_ports {leds[12]}]
set_property IOSTANDARD LVCMOS33 [get_ports {leds[12]}]

set_property PACKAGE_PIN V14 [get_ports {leds[13]}]
set_property IOSTANDARD LVCMOS33 [get_ports {leds[13]}]

set_property PACKAGE_PIN V12 [get_ports {leds[14]}]
set_property IOSTANDARD LVCMOS33 [get_ports {leds[14]}]

set_property PACKAGE_PIN V11 [get_ports {leds[15]}]
set_property IOSTANDARD LVCMOS33 [get_ports {leds[15]}]

set_property PACKAGE_PIN L18 [get_ports {LED_out[0]}]
set_property IOSTANDARD LVCMOS33 [get_ports {LED_out[0]}]

set_property PACKAGE_PIN T11 [get_ports {LED_out[1]}]
set_property IOSTANDARD LVCMOS33 [get_ports {LED_out[1]}]

set_property PACKAGE_PIN P15 [get_ports {LED_out[2]}]
set_property IOSTANDARD LVCMOS33 [get_ports {LED_out[2]}]

set_property PACKAGE_PIN K13 [get_ports {LED_out[3]}]
set_property IOSTANDARD LVCMOS33 [get_ports {LED_out[3]}]

set_property PACKAGE_PIN K16 [get_ports {LED_out[4]}]
set_property IOSTANDARD LVCMOS33 [get_ports {LED_out[4]}]

set_property PACKAGE_PIN R10 [get_ports {LED_out[5]}]
set_property IOSTANDARD LVCMOS33 [get_ports {LED_out[5]}]

set_property PACKAGE_PIN T10 [get_ports {LED_out[6]}]
set_property IOSTANDARD LVCMOS33 [get_ports {LED_out[6]}]

set_property PACKAGE_PIN J17 [get_ports {Anode[0]}]
set_property IOSTANDARD LVCMOS33 [get_ports {Anode[0]}]

set_property PACKAGE_PIN J18 [get_ports {Anode[1]}]
set_property IOSTANDARD LVCMOS33 [get_ports {Anode[1]}]

set_property PACKAGE_PIN T9 [get_ports {Anode[2]}]
set_property IOSTANDARD LVCMOS33 [get_ports {Anode[2]}]

set_property PACKAGE_PIN J14 [get_ports {Anode[3]}]
set_property IOSTANDARD LVCMOS33 [get_ports {Anode[3]}]

set_property PACKAGE_PIN T8 [get_ports {dbgReg[0]}]
set_property IOSTANDARD LVCMOS18 [get_ports {dbgReg[0]}]

set_property PACKAGE_PIN U8 [get_ports {dbgReg[1]}]
set_property IOSTANDARD LVCMOS18 [get_ports {dbgReg[1]}]

set_property PACKAGE_PIN R16 [get_ports {dbgReg[2]}]
set_property IOSTANDARD LVCMOS33 [get_ports {dbgReg[2]}]

set_property PACKAGE_PIN T13 [get_ports {dbgReg[3]}]
set_property IOSTANDARD LVCMOS33 [get_ports {dbgReg[3]}]

set_property PACKAGE_PIN H6 [get_ports {dbgReg[4]}]
set_property IOSTANDARD LVCMOS33 [get_ports {dbgReg[4]}]

## Left 4 digits of the 7-segment display (kept off)
set_property PACKAGE_PIN P14 [get_ports {Anode[4]}]
set_property IOSTANDARD LVCMOS33 [get_ports {Anode[4]}]
set_property PACKAGE_PIN T14 [get_ports {Anode[5]}]
set_property IOSTANDARD LVCMOS33 [get_ports {Anode[5]}]
set_property PACKAGE_PIN K2  [get_ports {Anode[6]}]
set_property IOSTANDARD LVCMOS33 [get_ports {Anode[6]}]
set_property PACKAGE_PIN U13 [get_ports {Anode[7]}]
set_property IOSTANDARD LVCMOS33 [get_ports {Anode[7]}]

set_property PACKAGE_PIN U11 [get_ports {fast}]
set_property IOSTANDARD LVCMOS33 [get_ports {fast}]
set_property PACKAGE_PIN V10 [get_ports {autoRun}]
set_property IOSTANDARD LVCMOS33 [get_ports {autoRun}]