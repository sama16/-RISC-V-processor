`timescale 1ns / 1ps


module ForwardingUnit (
    input      [4:0] ID_EX_rs1,
    input      [4:0] ID_EX_rs2,
    input      [4:0] EX_MEM_rd,
    input            EX_MEM_RegWrite,
    input            EX_MEM_MemRead,
    input      [4:0] MEM_WB_rd,
    input            MEM_WB_RegWrite,
    output reg [1:0] forwardA,
    output reg [1:0] forwardB
);

    wire ex_mem_ok = EX_MEM_RegWrite && !EX_MEM_MemRead && (EX_MEM_rd != 5'd0);
    wire mem_wb_ok = MEM_WB_RegWrite && (MEM_WB_rd != 5'd0);

    always @(*) begin
        // Operand A (rs1)
        if (ex_mem_ok && (EX_MEM_rd == ID_EX_rs1))
            forwardA = 2'b10;
        else if (mem_wb_ok && (MEM_WB_rd == ID_EX_rs1))
            forwardA = 2'b01;
        else
            forwardA = 2'b00;

        // Operand B (rs2)
        if (ex_mem_ok && (EX_MEM_rd == ID_EX_rs2))
            forwardB = 2'b10;
        else if (mem_wb_ok && (MEM_WB_rd == ID_EX_rs2))
            forwardB = 2'b01;
        else
            forwardB = 2'b00;
    end

endmodule
