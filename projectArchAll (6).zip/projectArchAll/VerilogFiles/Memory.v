`timescale 1ns / 1ps
module Memory #(
    parameter ADDR_BITS = 12,
    parameter INIT_FILE = ""
) (
    input                  clk,
    input                  MemRead,
    input                  MemWrite,
    input  [2:0]           funct3,
    input  [ADDR_BITS-1:0] addr,
    input  [31:0]          data_in,
    output reg [31:0]      data_out
);

    localparam ROWS = (1 << (ADDR_BITS - 2));      // 1024 rows of 4 bytes

    reg [7:0] bank0 [0:ROWS-1];
    reg [7:0] bank1 [0:ROWS-1];
    reg [7:0] bank2 [0:ROWS-1];
    reg [7:0] bank3 [0:ROWS-1];

    // ---------------- Initial contents ----------------
    integer i;
`ifndef SYNTHESIS
    reg [7:0] file_bytes [0:(1 << ADDR_BITS) - 1];   // simulation only (INIT_FILE)
`endif
    initial begin
        for (i = 0; i < ROWS; i = i + 1) begin
            bank0[i] = 8'h00; bank1[i] = 8'h00; bank2[i] = 8'h00; bank3[i] = 8'h00;
        end

        // PROGRAM_BEGIN
        // program: ALL board tests - ADD (x3=8), BEQ taken (x4=7, x6..x8 stay 0), SW/LW (x10=25, x11=26)
        bank3[0] = 8'h00; bank2[0] = 8'h50; bank1[0] = 8'h00; bank0[0] = 8'h93;   // 0x000: 00500093
        bank3[1] = 8'h00; bank2[1] = 8'h30; bank1[1] = 8'h01; bank0[1] = 8'h13;   // 0x004: 00300113
        bank3[2] = 8'h00; bank2[2] = 8'h20; bank1[2] = 8'h81; bank0[2] = 8'hb3;   // 0x008: 002081b3
        bank3[3] = 8'h00; bank2[3] = 8'h50; bank1[3] = 8'h02; bank0[3] = 8'h93;   // 0x00c: 00500293
        bank3[4] = 8'h00; bank2[4] = 8'h50; bank1[4] = 8'h88; bank0[4] = 8'h63;   // 0x010: 00508863
        bank3[5] = 8'h06; bank2[5] = 8'h30; bank1[5] = 8'h03; bank0[5] = 8'h13;   // 0x014: 06300313
        bank3[6] = 8'h06; bank2[6] = 8'h30; bank1[6] = 8'h03; bank0[6] = 8'h93;   // 0x018: 06300393
        bank3[7] = 8'h06; bank2[7] = 8'h30; bank1[7] = 8'h04; bank0[7] = 8'h13;   // 0x01c: 06300413
        bank3[8] = 8'h00; bank2[8] = 8'h70; bank1[8] = 8'h02; bank0[8] = 8'h13;   // 0x020: 00700213
        bank3[9] = 8'h01; bank2[9] = 8'h90; bank1[9] = 8'h04; bank0[9] = 8'h93;   // 0x024: 01900493
        bank3[10] = 8'h40; bank2[10] = 8'h90; bank1[10] = 8'h20; bank0[10] = 8'h23;   // 0x028: 40902023
        bank3[11] = 8'h40; bank2[11] = 8'h00; bank1[11] = 8'h25; bank0[11] = 8'h03;   // 0x02c: 40002503
        bank3[12] = 8'h00; bank2[12] = 8'h15; bank1[12] = 8'h05; bank0[12] = 8'h93;   // 0x030: 00150593
        bank3[13] = 8'h00; bank2[13] = 8'h10; bank1[13] = 8'h00; bank0[13] = 8'h73;   // 0x034: 00100073
        // PROGRAM_END

`ifndef SYNTHESIS
        if (INIT_FILE != "") begin
            $readmemh(INIT_FILE, file_bytes);
            for (i = 0; i < ROWS; i = i + 1) begin
                bank0[i] = file_bytes[4*i];     bank1[i] = file_bytes[4*i + 1];
                bank2[i] = file_bytes[4*i + 2]; bank3[i] = file_bytes[4*i + 3];
            end
        end
`endif
    end

    // ---------------- Address of each bank ----------------
    wire [1:0]            off = addr[1:0];
    wire [ADDR_BITS-3:0]  row = addr[ADDR_BITS-1:2];

    wire [ADDR_BITS-3:0]  row0 = row + (2'd0 < off);
    wire [ADDR_BITS-3:0]  row1 = row + (2'd1 < off);
    wire [ADDR_BITS-3:0]  row2 = row + (2'd2 < off);
    wire [ADDR_BITS-3:0]  row3 = row;

    // byte position (inside the 32-bit word) that each bank serves
    wire [1:0] k0 = 2'd0 - off;
    wire [1:0] k1 = 2'd1 - off;
    wire [1:0] k2 = 2'd2 - off;
    wire [1:0] k3 = 2'd3 - off;

    // number of bytes written: SB = 1, SH = 2, SW = 4
    wire [2:0] nbytes = (funct3[1:0] == 2'b00) ? 3'd1 :
                        (funct3[1:0] == 2'b01) ? 3'd2 : 3'd4;

    wire we0 = MemWrite && ({1'b0, k0} < nbytes);
    wire we1 = MemWrite && ({1'b0, k1} < nbytes);
    wire we2 = MemWrite && ({1'b0, k2} < nbytes);
    wire we3 = MemWrite && ({1'b0, k3} < nbytes);

    function [7:0] byte_of;
        input [31:0] word;
        input [1:0]  k;
        begin
            case (k)
                2'd0: byte_of = word[7:0];
                2'd1: byte_of = word[15:8];
                2'd2: byte_of = word[23:16];
                default: byte_of = word[31:24];
            endcase
        end
    endfunction

    // ---------------- Writes: one per bank, rising edge ----------------
    always @(posedge clk) if (we0) bank0[row0] <= byte_of(data_in, k0);
    always @(posedge clk) if (we1) bank1[row1] <= byte_of(data_in, k1);
    always @(posedge clk) if (we2) bank2[row2] <= byte_of(data_in, k2);
    always @(posedge clk) if (we3) bank3[row3] <= byte_of(data_in, k3);

    // ---------------- Reads: asynchronous, one per bank ----------------
    wire [7:0] q0 = bank0[row0];
    wire [7:0] q1 = bank1[row1];
    wire [7:0] q2 = bank2[row2];
    wire [7:0] q3 = bank3[row3];

    // byte k of the access comes from bank (off + k) mod 4
    function [7:0] pick;
        input [1:0] bank_no;
        input [7:0] a0, a1, a2, a3;
        begin
            case (bank_no)
                2'd0: pick = a0;
                2'd1: pick = a1;
                2'd2: pick = a2;
                default: pick = a3;
            endcase
        end
    endfunction

    wire [7:0] byte0 = pick(off,        q0, q1, q2, q3);
    wire [7:0] byte1 = pick(off + 2'd1, q0, q1, q2, q3);
    wire [7:0] byte2 = pick(off + 2'd2, q0, q1, q2, q3);
    wire [7:0] byte3 = pick(off + 2'd3, q0, q1, q2, q3);

    always @(*) begin
        if (!MemRead)
            data_out = 32'b0;
        else begin
            case (funct3)
                3'b000:  data_out = {{24{byte0[7]}}, byte0};                 // LB
                3'b001:  data_out = {{16{byte1[7]}}, byte1, byte0};          // LH
                3'b010:  data_out = {byte3, byte2, byte1, byte0};            // LW / fetch
                3'b100:  data_out = {24'b0, byte0};                          // LBU
                3'b101:  data_out = {16'b0, byte1, byte0};                   // LHU
                default: data_out = {byte3, byte2, byte1, byte0};
            endcase
        end
    end

endmodule