`timescale 1ns / 1ps


module Top (
    input         clk,          // 100 MHz board clock
    input         rclk,         // SW0  - manual CPU clock
    input         rst,          // SW1  - reset
    input  [1:0]  ledSel,       // SW3:2
    input  [3:0]  ssdSel,       // SW7:4
    input  [4:0]  dbgReg,       // SW12:8
    input         fast,         // SW14 - auto-run speed
    input         autoRun,      // SW15 - 1 = automatic clock
    output [15:0] leds,
    output [6:0]  LED_out,
    output [7:0]  Anode
);

    wire manual_clk;
    Debouncer #(.CNT_BITS(20)) clk_debouncer (
        .clk(clk), .btn_in(rclk), .btn_out(manual_clk)
    );

    reg [24:0] div = 25'd0;               
    always @(posedge clk)
        div <= div + 1'b1;

    wire auto_clk = fast ? div[16] : div[24];  
    wire cpu_clk  = autoRun ? auto_clk : manual_clk;

    // ---------------- CPU ----------------
    wire [12:0] ssd_value;
    wire        halted;

    femtoRV32 cpu (
        .clk(cpu_clk),
        .rst(rst),
        .ledSel(ledSel),
        .ssdSel(ssdSel),
        .dbgReg(dbgReg),
        .leds(leds),
        .ssd(ssd_value),
        .halted(halted)
    );

    // ---------------- 7-segment display (right 4 digits) ----------------
    wire [3:0] anode4;
    Four_Digit_Seven_Segment_Driver_Optimized ssd_driver (
        .clk(clk),
        .num(ssd_value),
        .Anode(anode4),
        .LED_out(LED_out)
    );

    assign Anode = {4'b1111, anode4};       // left 4 digits always off

endmodule