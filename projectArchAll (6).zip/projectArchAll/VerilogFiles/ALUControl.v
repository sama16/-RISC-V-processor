`timescale 1ns / 1ps
/

module ALUControl (
    input      [6:0] opcode,
    input      [2:0] funct3,
    input      [6:0] funct7,
    output reg [4:0] ALUSel
);

    localparam ALU_AND    = 5'd0;
    localparam ALU_OR     = 5'd1;
    localparam ALU_ADD    = 5'd2;
    localparam ALU_XOR    = 5'd3;
    localparam ALU_SLL    = 5'd4;
    localparam ALU_SRL    = 5'd5;
    localparam ALU_SUB    = 5'd6;
    localparam ALU_SRA    = 5'd7;
    localparam ALU_SLT    = 5'd8;
    localparam ALU_SLTU   = 5'd9;
    localparam ALU_MUL    = 5'd10;
    localparam ALU_MULH   = 5'd11;
    localparam ALU_MULHSU = 5'd12;
    localparam ALU_MULHU  = 5'd13;
    localparam ALU_DIV    = 5'd14;
    localparam ALU_DIVU   = 5'd15;
    localparam ALU_REM    = 5'd16;
    localparam ALU_REMU   = 5'd17;

    always @(*) begin
        ALUSel = ALU_ADD;

        case (opcode)
            // Register-register operations
            7'b0110011: begin
                if (funct7 == 7'b0000001) begin          // RV32M
                    case (funct3)
                        3'b000: ALUSel = ALU_MUL;
                        3'b001: ALUSel = ALU_MULH;
                        3'b010: ALUSel = ALU_MULHSU;
                        3'b011: ALUSel = ALU_MULHU;
                        3'b100: ALUSel = ALU_DIV;
                        3'b101: ALUSel = ALU_DIVU;
                        3'b110: ALUSel = ALU_REM;
                        3'b111: ALUSel = ALU_REMU;
                        default: ALUSel = ALU_MUL;
                    endcase
                end
                else begin
                    case (funct3)
                        3'b000: ALUSel = (funct7 == 7'b0100000) ? ALU_SUB : ALU_ADD;
                        3'b001: ALUSel = ALU_SLL;
                        3'b010: ALUSel = ALU_SLT;
                        3'b011: ALUSel = ALU_SLTU;
                        3'b100: ALUSel = ALU_XOR;
                        3'b101: ALUSel = (funct7 == 7'b0100000) ? ALU_SRA : ALU_SRL;
                        3'b110: ALUSel = ALU_OR;
                        3'b111: ALUSel = ALU_AND;
                        default: ALUSel = ALU_ADD;
                    endcase
                end
            end

            // Immediate operations
            7'b0010011: begin
                case (funct3)
                    3'b000: ALUSel = ALU_ADD;
                    3'b001: ALUSel = ALU_SLL;
                    3'b010: ALUSel = ALU_SLT;
                    3'b011: ALUSel = ALU_SLTU;
                    3'b100: ALUSel = ALU_XOR;
                    3'b101: ALUSel = (funct7 == 7'b0100000) ? ALU_SRA : ALU_SRL;
                    3'b110: ALUSel = ALU_OR;
                    3'b111: ALUSel = ALU_AND;
                    default: ALUSel = ALU_ADD;
                endcase
            end

            // Loads, stores, JALR, LUI, AUIPC: address / value = in1 + in2
            7'b0000011,
            7'b0100011,
            7'b1100111,
            7'b0110111,
            7'b0010111: ALUSel = ALU_ADD;

            // Branches (comparison itself is done by the branch unit)
            7'b1100011: ALUSel = ALU_SUB;

            default: ALUSel = ALU_ADD;
        endcase
    end

endmodule
