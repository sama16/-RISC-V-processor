`timescale 1ns / 1ps

module RegFile #(parameter N = 32) (
    input          clk,
    input          rst,
    input  [4:0]   readreg1,
    input  [4:0]   readreg2,
    input  [4:0]   readreg3,
    input  [4:0]   writereg,
    input  [N-1:0] writedata,
    input          regwrite,
    output [N-1:0] readdata1,
    output [N-1:0] readdata2,
    output [N-1:0] readdata3
);

    wire [N-1:0] Reg [0:31];
    wire [31:0]  load;

    decoder5x32 decoder (
        .in(writereg),
        .enable(regwrite && (writereg != 5'd0)),
        .out(load)
    );

    genvar i;
    generate
        for (i = 0; i < 32; i = i + 1) begin : gen_regs
            if (i == 0) begin : zero_reg
                assign Reg[i] = {N{1'b0}};
            end
            else begin : normal_regs
                N_bitRegister #(N) Regss (
                    .clk(clk),
                    .rst(rst),
                    .load(load[i]),
                    .D(writedata),
                    .Q(Reg[i])
                );
            end
        end
    endgenerate

    assign readdata1 = Reg[readreg1];
    assign readdata2 = Reg[readreg2];
    assign readdata3 = Reg[readreg3];

endmodule
