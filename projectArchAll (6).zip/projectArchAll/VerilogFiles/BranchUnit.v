`timescale 1ns / 1ps


module BranchUnit (
    input      [2:0]  funct3,
    input      [31:0] a,
    input      [31:0] b,
    output reg        cond
);

    wire eq  = (a == b);
    wire lt  = ($signed(a) < $signed(b));
    wire ltu = (a < b);

    always @(*) begin
        case (funct3)
            3'b000:  cond = eq;      // BEQ
            3'b001:  cond = ~eq;     // BNE
            3'b100:  cond = lt;      // BLT
            3'b101:  cond = ~lt;     // BGE
            3'b110:  cond = ltu;     // BLTU
            3'b111:  cond = ~ltu;    // BGEU
            default: cond = 1'b0;
        endcase
    end

endmodule
