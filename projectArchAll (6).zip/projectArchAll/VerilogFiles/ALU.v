`timescale 1ns / 1ps


module ALU (
    input      [31:0] in1,
    input      [31:0] in2,
    input      [4:0]  aluSel,
    output reg [31:0] result,
    output            Zero
);

    localparam ALU_AND    = 5'd0;
    localparam ALU_OR     = 5'd1;
    localparam ALU_ADD    = 5'd2;
    localparam ALU_XOR    = 5'd3;
    localparam ALU_SLL    = 5'd4;
    localparam ALU_SRL    = 5'd5;
    localparam ALU_SUB    = 5'd6;
    localparam ALU_SRA    = 5'd7;
    localparam ALU_SLT    = 5'd8;
    localparam ALU_SLTU   = 5'd9;
    localparam ALU_MUL    = 5'd10;
    localparam ALU_MULH   = 5'd11;
    localparam ALU_MULHSU = 5'd12;
    localparam ALU_MULHU  = 5'd13;
    localparam ALU_DIV    = 5'd14;
    localparam ALU_DIVU   = 5'd15;
    localparam ALU_REM    = 5'd16;
    localparam ALU_REMU   = 5'd17;

    // ---------------- Multiplication (64-bit products) ----------------
    wire signed [63:0] prod_ss = $signed(in1) * $signed(in2);
    wire        [63:0] prod_uu = in1 * in2;
    wire signed [65:0] prod_su = $signed({in1[31], in1}) * $signed({1'b0, in2});

    // ---------------- Division ----------------
    // Signed results are computed in their own signed wires so that the
    // surrounding (unsigned) expressions do not turn them into unsigned
    // division.
    wire div_by_zero  = (in2 == 32'b0);
    wire div_overflow = (in1 == 32'h80000000) && (in2 == 32'hFFFFFFFF);

    wire        [31:0] safe_div  = (div_by_zero | div_overflow) ? 32'd1 : in2;
    wire signed [31:0] quot_s    = $signed(in1) / $signed(safe_div);
    wire signed [31:0] rem_s     = $signed(in1) % $signed(safe_div);
    wire        [31:0] quot_u    = in1 / (div_by_zero ? 32'd1 : in2);
    wire        [31:0] rem_u     = in1 % (div_by_zero ? 32'd1 : in2);

    always @(*) begin
        case (aluSel)
            ALU_AND:    result = in1 & in2;
            ALU_OR:     result = in1 | in2;
            ALU_ADD:    result = in1 + in2;
            ALU_XOR:    result = in1 ^ in2;
            ALU_SLL:    result = in1 << in2[4:0];
            ALU_SRL:    result = in1 >> in2[4:0];
            ALU_SUB:    result = in1 - in2;
            ALU_SRA:    result = $signed(in1) >>> in2[4:0];
            ALU_SLT:    result = ($signed(in1) < $signed(in2)) ? 32'd1 : 32'd0;
            ALU_SLTU:   result = (in1 < in2) ? 32'd1 : 32'd0;

            ALU_MUL:    result = prod_uu[31:0];
            ALU_MULH:   result = prod_ss[63:32];
            ALU_MULHSU: result = prod_su[63:32];
            ALU_MULHU:  result = prod_uu[63:32];

            ALU_DIV:    result = div_by_zero  ? 32'hFFFFFFFF :
                                 div_overflow ? 32'h80000000 : quot_s;
            ALU_DIVU:   result = div_by_zero  ? 32'hFFFFFFFF : quot_u;
            ALU_REM:    result = div_by_zero  ? in1 :
                                 div_overflow ? 32'd0 : rem_s;
            ALU_REMU:   result = div_by_zero  ? in1 : rem_u;

            default:    result = 32'b0;
        endcase
    end

    assign Zero = (result == 32'b0);

endmodule