# =====================================================================
# Test 3 - control hazards. The instruction right after every taken
# branch/jump is fetched speculatively and must be FLUSHED.
# Wrong-path instructions are chosen to be harmful (store, ebreak,
# register write) so any missed flush shows up in the final state.
# =====================================================================
        addi  x30, x0, 0           # error counter
        addi  x31, x0, 0x400

        # taken branch, wrong-path register write
        beq   x0, x0, a1
        addi  x30, x30, 1
a1:     # taken branch, wrong-path STORE (must not reach memory)
        addi  x1, x0, 0x77
        bne   x1, x0, a2
        sw    x1, 0(x31)
a2:     # taken branch, wrong-path EBREAK (must NOT halt)
        blt   x0, x1, a3
        ebreak
a3:     # back-to-back taken branches
        beq   x0, x0, a4
a4:     beq   x0, x0, a5
        addi  x30, x30, 1
a5:     # branch to a branch
        jal   x0, a6
        addi  x30, x30, 1
a6:     bge   x1, x0, a7
        addi  x30, x30, 1
a7:     # not-taken branch must NOT flush the next instruction
        addi  x2, x0, 0
        bne   x0, x0, bad
        addi  x2, x2, 1            # must execute -> x2 = 1
        # JALR flush, wrong-path store
jr0:    auipc x3, 0
        jalr  x4, jr1-jr0(x3)
        sw    x1, 4(x31)           # wrong path: must be flushed
jr1:
        # backward branch loop: x5 = 1+2+...+10 = 55
        addi  x5, x0, 0
        addi  x6, x0, 1
        addi  x7, x0, 11
loop:   add   x5, x5, x6
        addi  x6, x6, 1
        bltu  x6, x7, loop
        sw    x5, 8(x31)
        # JAL forward over many instructions
        jal   x8, far
        addi  x30, x30, 1
        addi  x30, x30, 1
        addi  x30, x30, 1
far:    ebreak
        addi  x30, x30, 1000       # must never execute
bad:    addi  x30, x30, 100
        ebreak
