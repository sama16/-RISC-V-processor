`timescale 1ns / 1ps

module tb_hazard2_control;

    parameter PROGRAM_FILE = "hazard2_control.mem";

    // ---------------- the CPU ----------------
    reg clk = 0;
    reg rst = 1;
    reg [4:0] dbgReg = 5'd0;          // which register to read (debug port)
    wire [15:0] leds;
    wire [12:0] ssd;
    wire        halted;

    femtoRV32 dut (
        .clk(clk), .rst(rst),
        .ledSel(2'b00), .ssdSel(4'b0000), .dbgReg(dbgReg),
        .leds(leds), .ssd(ssd), .halted(halted)
    );

    always #5 clk = ~clk;             // clock: 10 ns period

    // ---------------- load the hex file into the CPU memory ----------------
    reg [31:0] program [0:1023];      // whole memory: 1024 words = 4 KB
    integer i;

    task load_program;
        begin
            for (i = 0; i < 1024; i = i + 1)
                program[i] = 32'h00000000;            // empty = 0
            $readmemh(PROGRAM_FILE, program);         // read the hex file
            for (i = 0; i < 1024; i = i + 1) begin    // word i -> address 4*i
                dut.memory.bank0[i] = program[i][7:0];
                dut.memory.bank1[i] = program[i][15:8];
                dut.memory.bank2[i] = program[i][23:16];
                dut.memory.bank3[i] = program[i][31:24];
            end
            if (program[0] === 32'h00000000)
                $display("ERROR: %s was not found or is empty", PROGRAM_FILE);
            else
                $display("Loaded %s", PROGRAM_FILE);
        end
    endtask

    // ---------------- checks ----------------
    integer passed = 0;
    integer failed = 0;

    task check_reg;                   // compare register x[r] with the answer
        input [4:0]      r;
        input [31:0]     expected;
        input [8*34-1:0] name;
        begin
            dbgReg = r;
            #1;
            if (dut.DebugRegData === expected) begin
                passed = passed + 1;
                $display("PASS  %s  x%0d = %h", name, r, dut.DebugRegData);
            end else begin
                failed = failed + 1;
                $display("FAIL  %s  x%0d = %h   expected = %h", name, r, dut.DebugRegData, expected);
            end
        end
    endtask

    task check_mem;                   // compare the memory word at an address
        input [11:0]     address;
        input [31:0]     expected;
        input [8*34-1:0] name;
        reg   [31:0]     word;
        begin
            word = {dut.memory.bank3[address[11:2]], dut.memory.bank2[address[11:2]],
                    dut.memory.bank1[address[11:2]], dut.memory.bank0[address[11:2]]};
            if (word === expected) begin
                passed = passed + 1;
                $display("PASS  %s  = %h", name, word);
            end else begin
                failed = failed + 1;
                $display("FAIL  %s  = %h   expected = %h", name, word, expected);
            end
        end
    endtask

    // ---------------- the test ----------------
    initial begin
        // 1. load the program from the hex file (after time 0)
        #1;
        load_program;

        // 2. reset for 2 cycles, then run until EBREAK stops the CPU
        #19 rst = 0;
        while (halted == 0 && $time < 3000)
            @(posedge clk);
        #50;                          // let the last instructions finish

        // 3. check the results
        $display("------------------------------------------------------------");
        $display("HAZARD 2: control hazards - flush after taken branches/jumps");
        $display("------------------------------------------------------------");
        check_reg(30, 32'h00000000, "error counter                     ");   // no wrong-path instruction ran: 0
        check_mem(12'h400, 32'h00000000, "wrong-path STORE after branch     ");   // flushed: memory stays 0
        check_reg( 2, 32'h00000001, "not-taken branch: next instr runs ");   // 1
        check_mem(12'h404, 32'h00000000, "wrong-path STORE after JALR       ");   // flushed: memory stays 0
        check_reg( 4, 32'h00000054, "JALR link                         ");   // return address
        check_reg( 5, 32'h00000037, "backward loop (BLTU)              ");   // 1+2+...+10 = 55
        check_mem(12'h408, 32'h00000037, "loop result stored                ");   // 55
        check_reg( 8, 32'h00000078, "JAL link over skipped code        ");   // return address
        if (dut.cycle_count == 32'd138) begin                // 50 instructions, 18 taken
            passed = passed + 1;
            $display("PASS  cycles = 2 x instr + 2 x taken + 2     cycles = %0d (CPI = 2)", dut.cycle_count);
        end else begin
            failed = failed + 1;
            $display("FAIL  cycles = %0d   expected = 138", dut.cycle_count);
        end
        if (halted && dut.PC == 32'h00000084) begin
            passed = passed + 1;
            $display("PASS  CPU halted at EBREAK                  PC = %h", dut.PC);
        end else begin
            failed = failed + 1;
            $display("FAIL  CPU halted at EBREAK                  PC = %h, halted = %b (expected PC 00000084)", dut.PC, halted);
        end

        // 4. summary
        $display("------------------------------------------------------------");
        $display("RESULT: %0d PASSED, %0d FAILED", passed, failed);
        if (failed == 0)
            $display("ALL TESTS PASSED");
        $display("------------------------------------------------------------");
        $finish;
    end

endmodule
