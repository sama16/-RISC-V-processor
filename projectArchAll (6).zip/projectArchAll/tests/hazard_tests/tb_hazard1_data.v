`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////


module tb_hazard1_data;

    parameter PROGRAM_FILE = "hazard1_data.mem";

    // ---------------- the CPU ----------------
    reg clk = 0;
    reg rst = 1;
    reg [4:0] dbgReg = 5'd0;          // which register to read (debug port)
    wire [15:0] leds;
    wire [12:0] ssd;
    wire        halted;

    femtoRV32 dut (
        .clk(clk), .rst(rst),
        .ledSel(2'b00), .ssdSel(4'b0000), .dbgReg(dbgReg),
        .leds(leds), .ssd(ssd), .halted(halted)
    );

    always #5 clk = ~clk;             // clock: 10 ns period

    // ---------------- load the hex file into the CPU memory ----------------
    reg [31:0] program [0:1023];      // whole memory: 1024 words = 4 KB
    integer i;

    task load_program;
        begin
            for (i = 0; i < 1024; i = i + 1)
                program[i] = 32'h00000000;            // empty = 0
            $readmemh(PROGRAM_FILE, program);         // read the hex file
            for (i = 0; i < 1024; i = i + 1) begin    // word i -> address 4*i
                dut.memory.bank0[i] = program[i][7:0];
                dut.memory.bank1[i] = program[i][15:8];
                dut.memory.bank2[i] = program[i][23:16];
                dut.memory.bank3[i] = program[i][31:24];
            end
            if (program[0] === 32'h00000000)
                $display("ERROR: %s was not found or is empty", PROGRAM_FILE);
            else
                $display("Loaded %s", PROGRAM_FILE);
        end
    endtask

    // ---------------- checks ----------------
    integer passed = 0;
    integer failed = 0;

    task check_reg;                   // compare register x[r] with the answer
        input [4:0]      r;
        input [31:0]     expected;
        input [8*34-1:0] name;
        begin
            dbgReg = r;
            #1;
            if (dut.DebugRegData === expected) begin
                passed = passed + 1;
                $display("PASS  %s  x%0d = %h", name, r, dut.DebugRegData);
            end else begin
                failed = failed + 1;
                $display("FAIL  %s  x%0d = %h   expected = %h", name, r, dut.DebugRegData, expected);
            end
        end
    endtask

    task check_mem;                   // compare the memory word at an address
        input [11:0]     address;
        input [31:0]     expected;
        input [8*34-1:0] name;
        reg   [31:0]     word;
        begin
            word = {dut.memory.bank3[address[11:2]], dut.memory.bank2[address[11:2]],
                    dut.memory.bank1[address[11:2]], dut.memory.bank0[address[11:2]]};
            if (word === expected) begin
                passed = passed + 1;
                $display("PASS  %s  = %h", name, word);
            end else begin
                failed = failed + 1;
                $display("FAIL  %s  = %h   expected = %h", name, word, expected);
            end
        end
    endtask

    // ---------------- the test ----------------
    initial begin
        // 1. load the program from the hex file (after time 0)
        #1;
        load_program;

        // 2. reset for 2 cycles, then run until EBREAK stops the CPU
        #19 rst = 0;
        while (halted == 0 && $time < 3000)
            @(posedge clk);
        #50;                          // let the last instructions finish

        // 3. check the results
        $display("------------------------------------------------------------");
        $display("HAZARD 1: data hazards (RAW) - forwarding, load-use, x0, store/branch/JALR operands");
        $display("------------------------------------------------------------");
        check_reg( 2, 32'h00000008, "ALU->ALU operand A                ");   // addi x2,x1,3 sees x1=5 -> 8
        check_reg( 3, 32'h00000008, "ALU->ALU operand B                ");   // add x3,x0,x2 sees x2=8
        check_reg( 4, 32'h00000010, "both operands same producer       ");   // x3+x3 = 16
        check_reg( 5, 32'h00000014, "chain of 4 dependent addi         ");   // 16+1+1+1+1 = 20
        check_reg( 7, 32'h00000002, "newest value wins                 ");   // x6 written 1 then 2 -> 2
        check_reg( 8, 32'h00000000, "write to x0 not forwarded         ");   // must be 0
        check_mem(12'h400, 32'h00000055, "ALU->store data                   ");   // sw x9 right after addi x9
        check_mem(12'h408, 32'h00000055, "ALU->store address                ");   // sw x9,0(x10) right after addi x10
        check_reg(12, 32'h00000056, "load->use (no stall)              ");   // lw x11 then addi x12,x11,1 = 0x56
        check_mem(12'h404, 32'h00000055, "load->store data                  ");   // lw x13 then sw x13
        check_reg(16, 32'h0000040c, "load->load address                ");   // address comes from previous load
        check_reg(21, 32'h00000090, "ALU->JALR base                    ");   // return address of the jalr
        check_reg(23, 32'h00000098, "JAL link->use                     ");   // x22 used right after jal
        check_reg(24, 32'h00001001, "LUI->use                          ");   // 0x1000 + 1
        check_reg(26, 32'h0000000c, "AUIPC->use                        ");   // x25 used right after auipc
        check_reg(30, 32'h00000000, "error counter (branches)          ");   // ALU->branch, load->branch: 0 errors
        if (dut.cycle_count == 32'd90) begin                // 41 instructions, 3 taken
            passed = passed + 1;
            $display("PASS  cycles = 2 x instr + 2 x taken + 2     cycles = %0d (CPI = 2)", dut.cycle_count);
        end else begin
            failed = failed + 1;
            $display("FAIL  cycles = %0d   expected = 90", dut.cycle_count);
        end
        if (halted && dut.PC == 32'h000000ac) begin
            passed = passed + 1;
            $display("PASS  CPU halted at EBREAK                  PC = %h", dut.PC);
        end else begin
            failed = failed + 1;
            $display("FAIL  CPU halted at EBREAK                  PC = %h, halted = %b (expected PC 000000ac)", dut.PC, halted);
        end

        // 4. summary
        $display("------------------------------------------------------------");
        $display("RESULT: %0d PASSED, %0d FAILED", passed, failed);
        if (failed == 0)
            $display("ALL TESTS PASSED");
        $display("------------------------------------------------------------");
        $finish;
    end

endmodule
