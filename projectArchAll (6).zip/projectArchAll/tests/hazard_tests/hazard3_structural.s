
# hazard3 - STRUCTURAL hazard: ONE memory for instructions AND data.
# Loads/stores are back-to-back with fetches; the CPU issues one instruction
# every 2 cycles (C0 = fetch uses memory, C1 = load/store uses memory), so the
# two never collide. Expected: all values correct AND cycles = 2 x instructions + 3.
        addi  x31, x0, 0x400
        addi  x1, x0, 0x11
        addi  x2, x0, 0x22
        sw    x1, 0(x31)           # data write   (C1)  while next fetch waits for C0
        sw    x2, 4(x31)           # data write
        lw    x3, 0(x31)           # data read
        lw    x4, 4(x31)           # data read
        sw    x3, 8(x31)           # store of a value just loaded
        lw    x5, 8(x31)
        add   x6, x4, x5           # 0x22 + 0x11 = 0x33
        sw    x6, 12(x31)
        lw    x7, 12(x31)
        lw    x8, 0(x0)            # read an INSTRUCTION word as data (same memory)
        ebreak
