`timescale 1ns / 1ps


module tb_type3_loads;

parameter PROGRAM_FILE = "C:/Users/SamaAlmallak/Desktop/tests/hex_type_tests/type3_loads.mem";
    // ---------------- the CPU ----------------
    reg clk = 0;
    reg rst = 1;
    reg [4:0] dbgReg = 5'd0;          // which register to read (debug port)
    wire [15:0] leds;
    wire [12:0] ssd;
    wire        halted;

    femtoRV32 dut (
        .clk(clk), .rst(rst),
        .ledSel(2'b00), .ssdSel(4'b0000), .dbgReg(dbgReg),
        .leds(leds), .ssd(ssd), .halted(halted)
    );

    always #5 clk = ~clk;             // clock: 10 ns period

    // ---------------- load the hex file into the CPU memory ----------------
    reg [31:0] program [0:1023];      // whole memory: 1024 words = 4 KB
    integer i;

    task load_program;
        begin
            for (i = 0; i < 1024; i = i + 1)
                program[i] = 32'h00000000;            // empty = 0
            $readmemh(PROGRAM_FILE, program);         // read the hex file
            for (i = 0; i < 1024; i = i + 1) begin    // word i -> address 4*i
                dut.memory.bank0[i] = program[i][7:0];
                dut.memory.bank1[i] = program[i][15:8];
                dut.memory.bank2[i] = program[i][23:16];
                dut.memory.bank3[i] = program[i][31:24];
            end
            if (program[0] === 32'h00000000)
                $display("ERROR: %s was not found or is empty", PROGRAM_FILE);
            else
                $display("Loaded %s", PROGRAM_FILE);
        end
    endtask

    // ---------------- checks ----------------
    integer passed = 0;
    integer failed = 0;

    task check_reg;                   // compare register x[r] with the answer
        input [4:0]      r;
        input [31:0]     expected;
        input [8*34-1:0] name;
        begin
            dbgReg = r;
            #1;
            if (dut.DebugRegData === expected) begin
                passed = passed + 1;
                $display("PASS  %s  x%0d = %h", name, r, dut.DebugRegData);
            end else begin
                failed = failed + 1;
                $display("FAIL  %s  x%0d = %h   expected = %h", name, r, dut.DebugRegData, expected);
            end
        end
    endtask

    task check_mem;                   // compare the memory word at an address
        input [11:0]     address;
        input [31:0]     expected;
        input [8*34-1:0] name;
        reg   [31:0]     word;
        begin
            word = {dut.memory.bank3[address[11:2]], dut.memory.bank2[address[11:2]],
                    dut.memory.bank1[address[11:2]], dut.memory.bank0[address[11:2]]};
            if (word === expected) begin
                passed = passed + 1;
                $display("PASS  %s  = %h", name, word);
            end else begin
                failed = failed + 1;
                $display("FAIL  %s  = %h   expected = %h", name, word, expected);
            end
        end
    endtask

    // ---------------- the test ----------------
    initial begin
        // 1. load the program from the hex file (after time 0)
        #1;
        load_program;

        // 2. reset for 2 cycles, then run until EBREAK stops the CPU
        #19 rst = 0;
        while (halted == 0 && $time < 950)
            @(posedge clk);
        #50;                          // let the last instructions finish

        // 3. check the results
        $display("------------------------------------------------------------");
        $display("Loads: all 5 instructions (opcode 0000011)");
        $display("------------------------------------------------------------");
        check_reg( 3, 32'hfffffff9, "LB  x3, 0(x10)                    ");   // byte F9 -> sign-extended
        check_reg( 4, 32'h0000007f, "LB  x4, 3(x10)                    ");   // byte 7F -> positive
        check_reg( 5, 32'hfffff0f9, "LH  x5, 0(x10)                    ");   // halfword F0F9 -> sign-extended
        check_reg( 6, 32'h00007f80, "LH  x6, 2(x10)                    ");   // halfword 7F80 -> positive
        check_reg( 7, 32'h7f80f0f9, "LW  x7, 0(x10)                    ");   // whole word
        check_reg( 8, 32'h000000f9, "LBU x8, 0(x10)                    ");   // byte F9 -> zero-extended
        check_reg( 9, 32'h0000f0f9, "LHU x9, 0(x10)                    ");   // halfword F0F9 -> zero-extended
        check_reg(11, 32'h12345678, "LW  x11, 4(x10)                   ");   // word at 0x404
        check_reg(12, 32'h12345678, "LW  x12, -4(x13)                  ");   // negative offset, word at 0x404
        if (halted && dut.PC == 32'h0000002c) begin
            passed = passed + 1;
            $display("PASS  CPU halted at EBREAK                  PC = %h", dut.PC);
        end else begin
            failed = failed + 1;
            $display("FAIL  CPU halted at EBREAK                  PC = %h, halted = %b (expected PC 0000002c)", dut.PC, halted);
        end

        // 4. summary
        $display("------------------------------------------------------------");
        $display("RESULT: %0d PASSED, %0d FAILED", passed, failed);
        if (failed == 0)
            $display("ALL TESTS PASSED");
        $display("------------------------------------------------------------");
        $finish;
    end

endmodule
