`timescale 1ns / 1ps

module tb_type5_branches;

    parameter PROGRAM_FILE = "type5_branches.mem";

    // ---------------- the CPU ----------------
    reg clk = 0;
    reg rst = 1;
    reg [4:0] dbgReg = 5'd0;          // which register to read (debug port)
    wire [15:0] leds;
    wire [12:0] ssd;
    wire        halted;

    femtoRV32 dut (
        .clk(clk), .rst(rst),
        .ledSel(2'b00), .ssdSel(4'b0000), .dbgReg(dbgReg),
        .leds(leds), .ssd(ssd), .halted(halted)
    );

    always #5 clk = ~clk;             // clock: 10 ns period

    // ---------------- load the hex file into the CPU memory ----------------
    reg [31:0] program [0:1023];      // whole memory: 1024 words = 4 KB
    integer i;

    task load_program;
        begin
            for (i = 0; i < 1024; i = i + 1)
                program[i] = 32'h00000000;            // empty = 0
            $readmemh(PROGRAM_FILE, program);         // read the hex file
            for (i = 0; i < 1024; i = i + 1) begin    // word i -> address 4*i
                dut.memory.bank0[i] = program[i][7:0];
                dut.memory.bank1[i] = program[i][15:8];
                dut.memory.bank2[i] = program[i][23:16];
                dut.memory.bank3[i] = program[i][31:24];
            end
            if (program[0] === 32'h00000000)
                $display("ERROR: %s was not found or is empty", PROGRAM_FILE);
            else
                $display("Loaded %s", PROGRAM_FILE);
        end
    endtask

    // ---------------- checks ----------------
    integer passed = 0;
    integer failed = 0;

    task check_reg;                   // compare register x[r] with the answer
        input [4:0]      r;
        input [31:0]     expected;
        input [8*34-1:0] name;
        begin
            dbgReg = r;
            #1;
            if (dut.DebugRegData === expected) begin
                passed = passed + 1;
                $display("PASS  %s  x%0d = %h", name, r, dut.DebugRegData);
            end else begin
                failed = failed + 1;
                $display("FAIL  %s  x%0d = %h   expected = %h", name, r, dut.DebugRegData, expected);
            end
        end
    endtask

    task check_mem;                   // compare the memory word at an address
        input [11:0]     address;
        input [31:0]     expected;
        input [8*34-1:0] name;
        reg   [31:0]     word;
        begin
            word = {dut.memory.bank3[address[11:2]], dut.memory.bank2[address[11:2]],
                    dut.memory.bank1[address[11:2]], dut.memory.bank0[address[11:2]]};
            if (word === expected) begin
                passed = passed + 1;
                $display("PASS  %s  = %h", name, word);
            end else begin
                failed = failed + 1;
                $display("FAIL  %s  = %h   expected = %h", name, word, expected);
            end
        end
    endtask

    // ---------------- the test ----------------
    initial begin
        // 1. load the program from the hex file (after time 0)
        #1;
        load_program;

        // 2. reset for 2 cycles, then run until EBREAK stops the CPU
        #19 rst = 0;
        while (halted == 0 && $time < 950)
            @(posedge clk);
        #50;                          // let the last instructions finish

        // 3. check the results
        $display("------------------------------------------------------------");
        $display("Branches: all 6 instructions (opcode 1100011)");
        $display("------------------------------------------------------------");
        check_reg( 3, 32'h00000001, "BEQ                               ");   // 1 = taken once + not taken once
        check_reg( 4, 32'h00000001, "BNE                               ");   // 1 = taken once + not taken once
        check_reg( 5, 32'h00000001, "BLT                               ");   // 1 = taken once + not taken once
        check_reg( 6, 32'h00000001, "BGE                               ");   // 1 = taken once + not taken once
        check_reg( 7, 32'h00000001, "BLTU                              ");   // 1 = taken once + not taken once
        check_reg( 8, 32'h00000001, "BGEU                              ");   // 1 = taken once + not taken once
        check_reg( 9, 32'h00000006, "BNE backward (loop)               ");   // 1+2+3 = 6
        if (halted && dut.PC == 32'h0000007c) begin
            passed = passed + 1;
            $display("PASS  CPU halted at EBREAK                  PC = %h", dut.PC);
        end else begin
            failed = failed + 1;
            $display("FAIL  CPU halted at EBREAK                  PC = %h, halted = %b (expected PC 0000007c)", dut.PC, halted);
        end

        // 4. summary
        $display("------------------------------------------------------------");
        $display("RESULT: %0d PASSED, %0d FAILED", passed, failed);
        if (failed == 0)
            $display("ALL TESTS PASSED");
        $display("------------------------------------------------------------");
        $finish;
    end

endmodule
