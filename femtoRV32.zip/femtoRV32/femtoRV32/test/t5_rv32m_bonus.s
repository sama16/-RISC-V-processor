# =====================================================================
# Test 5 - RV32M bonus: all 8 instructions including the corner cases
# defined by the specification (divide by zero, signed overflow).
# =====================================================================
        addi  x1, x0, -7
        addi  x2, x0, 3
        lui   x3, 0x80000          # x3 = -2^31
        addi  x4, x0, -1
        mul    x5,  x1, x2         # -21
        mulh   x6,  x1, x2         # -1 (upper half)
        mulhsu x7,  x1, x4         # -7 * 0xFFFFFFFF (unsigned) upper
        mulhu  x8,  x4, x4         # 0xFFFFFFFE
        div    x9,  x1, x2         # -2 (truncates toward zero)
        divu   x10, x1, x2
        rem    x11, x1, x2         # -1 (sign of dividend)
        remu   x12, x1, x2
        div    x13, x1, x0         # divide by zero -> -1
        divu   x14, x1, x0         # -> 0xFFFFFFFF
        rem    x15, x1, x0         # -> dividend
        remu   x16, x1, x0         # -> dividend
        div    x17, x3, x4         # overflow -> -2^31
        rem    x18, x3, x4         # overflow -> 0
        mul    x19, x5, x5         # hazard into M unit: 441
        ebreak
