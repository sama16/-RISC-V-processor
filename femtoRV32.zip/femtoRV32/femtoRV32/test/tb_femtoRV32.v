`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Module Name: tb_one_rtype
// Description: Tests ONE R-type instruction (ADD) and prints PASS or FAIL.
//
//   The testbench writes this tiny program into the memory itself
//   (so it works with any Memory.v):
//
//       address  machine code   instruction
//       0x000    ff900093       addi x1, x0, -7      x1 = -7
//       0x004    00300113       addi x2, x0, 3       x2 = 3
//       0x008    002081b3       add  x3, x1, x2      x3 = x1 + x2   <-- tested
//       0x00c    00100073       ebreak               stop
//
//   Correct answer: x3 = -7 + 3 = -4 = 0xFFFFFFFC
//
//   How the ADD machine code 002081b3 is built (R-type format):
//       funct7   rs2    rs1    funct3  rd     opcode
//       0000000  00010  00001  000     00011  0110011
//       (ADD)    (x2)   (x1)   (ADD)   (x3)   (R-type)
//////////////////////////////////////////////////////////////////////////////////

module tb_one_rtype;

    // ---------------- the CPU ----------------
    reg clk = 0;
    reg rst = 1;
    reg [4:0] dbgReg = 5'd3;          // read register x3 through the debug port
    wire [15:0] leds;
    wire [12:0] ssd;
    wire        halted;

    femtoRV32 dut (
        .clk(clk), .rst(rst),
        .ledSel(2'b00), .ssdSel(4'b0000), .dbgReg(dbgReg),
        .leds(leds), .ssd(ssd), .halted(halted)
    );

    always #5 clk = ~clk;             // clock: 10 ns period

    // ---------------- write one 32-bit word into the memory ----------------
    task put;
        input [11:0] address;
        input [31:0] word;
        begin
            dut.memory.bank0[address[11:2]] = word[7:0];
            dut.memory.bank1[address[11:2]] = word[15:8];
            dut.memory.bank2[address[11:2]] = word[23:16];
            dut.memory.bank3[address[11:2]] = word[31:24];
        end
    endtask

    // ---------------- the test ----------------
    initial begin
        // 1. load the program (after time 0, so it overwrites Memory.v's program)
        #1;
        put(12'h000, 32'hff900093);   // addi x1, x0, -7
        put(12'h004, 32'h00300113);   // addi x2, x0, 3
        put(12'h008, 32'h002081b3);   // add  x3, x1, x2
        put(12'h00c, 32'h00100073);   // ebreak

        // 2. reset, then let the CPU run until EBREAK stops it
        #19 rst = 0;
        wait (halted == 1 || $time > 2000);
        #100;                         // let the last instruction finish

        // 3. check the result
        $display("--------------------------------------------");
        $display("Testing: add x3, x1, x2   with x1 = -7, x2 = 3");
        $display("x1 = %h, x2 = %h", dut.reg_file.Reg[1], dut.reg_file.Reg[2]);
        if (dut.DebugRegData === 32'hfffffffc)
            $display("PASS  ADD  x3 = %h  (expected fffffffc = -4)", dut.DebugRegData);
        else
            $display("FAIL  ADD  x3 = %h  (expected fffffffc = -4)", dut.DebugRegData);
        $display("--------------------------------------------");
        $finish;
    end

endmodule