# =====================================================================
# Test 4 - the five special instructions.
# ECALL, FENCE, FENCE.TSO, PAUSE must do nothing; EBREAK must halt and
# nothing after it may change state.
# =====================================================================
        addi  x1, x0, 1
        ecall
        addi  x1, x1, 1            # 2
        fence
        addi  x1, x1, 1            # 3
        fence.tso
        addi  x1, x1, 1            # 4
        pause
        addi  x1, x1, 1            # 5
        # special instructions surrounded by a RAW hazard
        addi  x2, x0, 10
        ecall
        add   x3, x2, x1           # 15
        addi  x31, x0, 0x400
        sw    x3, 0(x31)
        ebreak
        addi  x1, x0, 99           # must never execute
        sw    x1, 4(x31)           # must never execute
        addi  x4, x0, 99           # must never execute
