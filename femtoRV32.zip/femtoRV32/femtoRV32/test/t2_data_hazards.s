# =====================================================================
# Test 2 - data hazards (RAW). Every pair below is back-to-back, so the
# consumer is in EX while the producer is in WB -> MEM/WB forwarding.
# x30 = error counter, must end at 0.
# =====================================================================
        addi  x30, x0, 0
        addi  x31, x0, 0x400       # data base

        # ALU -> ALU, operand A (rs1)
        addi  x1, x0, 5
        addi  x2, x1, 3            # needs x1 = 5   -> 8
        # ALU -> ALU, operand B (rs2)
        add   x3, x0, x2           # needs x2 = 8   -> 8
        # both operands from the same producer
        add   x4, x3, x3           # 16
        # chain of 4 dependent instructions
        addi  x5, x4, 1            # 17
        addi  x5, x5, 1            # 18
        addi  x5, x5, 1            # 19
        addi  x5, x5, 1            # 20
        # most-recent value wins (x6 written twice, read right after)
        addi  x6, x0, 1
        addi  x6, x0, 2
        add   x7, x6, x0           # must see 2, not 1

        # writes to x0 must NOT be forwarded
        addi  x0, x0, 99
        add   x8, x0, x0           # must be 0

        # ALU -> store data and store address
        addi  x9, x0, 0x55
        sw    x9, 0(x31)           # store data forwarded
        addi  x10, x31, 8
        sw    x9, 0(x10)           # store address forwarded

        # load -> use (no stall needed with 2-cycle issue)
        lw    x11, 0(x31)          # 0x55
        addi  x12, x11, 1          # 0x56
        # load -> store data
        lw    x13, 8(x31)          # 0x55
        sw    x13, 4(x31)
        # load -> load address
        addi  x14, x0, 0x40C
        sw    x14, 12(x31)         # mem[0x40C] = 0x40C
        lw    x15, 12(x31)         # x15 = 0x40C
        lw    x16, 0(x15)          # address from previous load -> 0x40C

        # ALU -> branch (both operands)
        addi  x17, x0, 7
        addi  x18, x0, 7
        beq   x17, x18, ok1
        addi  x30, x30, 1
ok1:    # load -> branch
        lw    x19, 0(x31)          # 0x55
        bne   x19, x9, bad
        # ALU -> JALR base register
        auipc x20, 0
        addi  x20, x20, 16         # address of ok2
        jalr  x21, 0(x20)
        addi  x30, x30, 1          # skipped
ok2:    # JAL link -> use
        jal   x22, ok3
ok3:    addi  x23, x22, 0          # x23 = address of ok3
        # LUI -> use, AUIPC -> use
        lui   x24, 0x1
        addi  x24, x24, 1          # 0x1001
        auipc x25, 0
        sub   x26, x25, x23        # constant distance

        ebreak
bad:    addi  x30, x30, 100
        ebreak
