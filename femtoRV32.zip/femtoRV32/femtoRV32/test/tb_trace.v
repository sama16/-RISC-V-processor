`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Module Name: tb_trace
// Description: Prints one line per clock cycle with the main pipeline signals
//              (used to produce the cycle-by-cycle trace / waveform figures).
//              Columns: cycle phase PC IF_ID_Inst ID_EX_Inst EX_MEM_Inst
//                       MEM_WB_Inst forwardA forwardB redirect halted
//                       MEM_WB_RegWrite MEM_WB_rd WriteBackData
//////////////////////////////////////////////////////////////////////////////////

`ifndef HEXFILE
  `define HEXFILE "program.hex"
`endif

module tb_trace;

    reg clk = 1'b0;
    reg rst = 1'b1;
    wire [15:0] leds;
    wire [12:0] ssd;
    wire        halted;

    femtoRV32 #(.MEM_INIT(`HEXFILE)) dut (
        .clk(clk), .rst(rst), .ledSel(2'b00), .ssdSel(4'b0000),
        .dbgReg(5'd0), .leds(leds), .ssd(ssd), .halted(halted)
    );

    always #5 clk = ~clk;

    integer cycle = 0;

    initial begin
        #12 rst = 1'b0;
        repeat (400) begin
            #2;   // sample just after the rising edge has settled
            $display("%0d %0d %08x %08x:%08x %08x:%08x %08x:%08x %08x:%08x %0d %0d %0d %0d %0d %0d %08x",
                     cycle, dut.phase, dut.PC, dut.IF_ID_Inst, dut.IF_ID_PC,
                     dut.ID_EX_Inst, dut.ID_EX_PC, dut.EX_MEM_Inst, dut.EX_MEM_PCplus4 - 4,
                     dut.MEM_WB_Inst, dut.MEM_WB_PCplus4 - 4, dut.forwardA, dut.forwardB,
                     dut.redirect, halted, dut.MEM_WB_RegWrite, dut.MEM_WB_rd,
                     dut.WriteBackData);
            @(posedge clk);
            cycle = cycle + 1;
            if (halted && cycle > 10) begin
                repeat (6) begin
                    #2;
                    $display("%0d %0d %08x %08x:%08x %08x:%08x %08x:%08x %08x:%08x %0d %0d %0d %0d %0d %0d %08x",
                             cycle, dut.phase, dut.PC, dut.IF_ID_Inst, dut.IF_ID_PC,
                             dut.ID_EX_Inst, dut.ID_EX_PC, dut.EX_MEM_Inst, dut.EX_MEM_PCplus4 - 4,
                             dut.MEM_WB_Inst, dut.MEM_WB_PCplus4 - 4, dut.forwardA, dut.forwardB,
                             dut.redirect, halted, dut.MEM_WB_RegWrite, dut.MEM_WB_rd,
                             dut.WriteBackData);
                    @(posedge clk);
                    cycle = cycle + 1;
                end
                $finish;
            end
        end
        $finish;
    end

endmodule
