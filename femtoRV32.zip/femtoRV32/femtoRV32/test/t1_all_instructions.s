# =====================================================================
# Test 1 - every RV32I instruction (37 real + 5 special) at least once.
# Instructions are separated by independent ones where useful, but
# hazards are NOT avoided (the pipeline must handle them anyway).
# Data region starts at 0x400 (see .org at the bottom).
# Expected final values are checked automatically against iss.py.
# =====================================================================

        # ---------- U-type ----------
        lui   x1, 0x12345          # x1 = 0x12345000
        auipc x2, 0x1              # x2 = 0x4 + 0x1000 = 0x1004

        # ---------- I-type ALU ----------
        addi  x3, x0, 100          # x3 = 100
        addi  x4, x0, -7           # x4 = -7 (0xFFFFFFF9)
        slti  x5, x4, 0            # x5 = 1  (-7 < 0)
        sltiu x6, x3, 50           # x6 = 0  (100 < 50 unsigned? no)
        xori  x7, x3, 0x0F         # x7 = 100 ^ 15 = 107
        ori   x8, x3, 0x700        # x8 = 0x764
        andi  x9, x4, 0x0F0        # x9 = 0xF0 & 0xFFFFFFF9 = 0xF0
        slli  x10, x3, 4           # x10 = 1600
        srli  x11, x4, 28          # x11 = 0xF
        srai  x12, x4, 1           # x12 = -4 (0xFFFFFFFC)

        # ---------- R-type ----------
        add   x13, x3, x4          # 93
        sub   x14, x4, x3          # -107
        sll   x15, x3, x11         # 100 << 15 = 3276800
        slt   x16, x4, x3          # 1
        sltu  x17, x4, x3          # 0 (0xFFFFFFF9 > 100 unsigned)
        xor   x18, x3, x4          # 100 ^ -7
        srl   x19, x4, x11         # 0xFFFFFFF9 >> 15 = 0x1FFFF
        sra   x20, x4, x11         # -7 >>> 15 = -1
        or    x21, x3, x9          # 100 | 0xF0 = 0xF4
        and   x22, x3, x7          # 100 & 107 = 96

        # ---------- Stores / loads ----------
        addi  x23, x0, 0x400       # data base
        sw    x4,  0(x23)          # mem[0x400] = 0xFFFFFFF9
        sh    x3,  4(x23)          # mem[0x404] = 0x0064
        sb    x7,  6(x23)          # mem[0x406] = 0x6B
        lw    x24, 0(x23)          # 0xFFFFFFF9
        lh    x25, 0(x23)          # 0xFFFFFFF9 (sign-extended half 0xFFF9)
        lhu   x26, 0(x23)          # 0x0000FFF9
        lb    x27, 0(x23)          # 0xFFFFFFF9
        lbu   x28, 0(x23)          # 0x000000F9
        lw    x29, 4(x23)          # 0x006B0064

        # ---------- Special instructions (no-ops) ----------
        ecall
        fence
        fence.tso
        pause

        # ---------- Branches: each one taken once and not-taken once ----------
        addi  x30, x0, 0           # x30 counts mistakes (must stay 0)
        beq   x3, x3, b1           # taken
        addi  x30, x30, 1
b1:     beq   x3, x4, fail         # not taken
        bne   x3, x4, b2           # taken
        addi  x30, x30, 1
b2:     bne   x3, x3, fail         # not taken
        blt   x4, x3, b3           # taken  (-7 < 100)
        addi  x30, x30, 1
b3:     blt   x3, x4, fail         # not taken
        bge   x3, x4, b4           # taken
        addi  x30, x30, 1
b4:     bge   x4, x3, fail         # not taken
        bltu  x3, x4, b5           # taken  (100 < 0xFFFFFFF9)
        addi  x30, x30, 1
b5:     bltu  x4, x3, fail         # not taken
        bgeu  x4, x3, b6           # taken
        addi  x30, x30, 1
b6:     bgeu  x3, x4, fail         # not taken

        # ---------- Jumps ----------
        jal   x31, j1              # x31 = address of next instruction
        addi  x30, x30, 1          # skipped
j1:     auipc x5, 0                # x5 = address of this instruction
        jalr  x6, 16(x5)           # jump to j2, x6 = return address
        addi  x30, x30, 1          # skipped
        addi  x30, x30, 1          # skipped
j2:     sw    x31, 8(x23)          # record link values in memory
        sw    x6, 12(x23)
        ebreak                     # HALT
        addi  x30, x30, 100        # must never execute

fail:   addi  x30, x30, 1000
        ebreak

        .org 0x400
        .word 0                    # data area (written by the program)
