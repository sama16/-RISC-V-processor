CSCE 3301 - Computer Architecture - Fall 2026
Project 1: femtoRV32 - Milestone 3 (pipelined, single memory)

Team members
------------
- Sama Almallak   (ID: ________)   - team leader
- ______________  (ID: ________)

Directory structure
-------------------
Verilog/       all Verilog sources (top for FPGA: Top.v, CPU core: femtoRV32.v)
               program.hex = program loaded into the memory on the FPGA (test 1)
constraints/   NexysA7.xdc (Nexys A7-100T pin assignments)
test/          testbench (tb_femtoRV32.v), test programs (*.s), machine code
               (*.hex, one byte per line) and listings (*.lst), results/
               random/ = generated random programs (bonus 6)
tools/         rvasm.py (assembler), iss.py (golden reference simulator),
               gen_random.py (random test generator - bonus 6), run_tests.py
journal/       one journal file per team member
report.pdf     design report

Design summary
--------------
* RV32I: all 42 user-level instructions. EBREAK halts (the PC stops being
  updated); ECALL, FENCE, FENCE.TSO and PAUSE are no-operations.
* 5-stage pipeline IF-ID-EX-MEM-WB with pipeline registers IF/ID, ID/EX,
  EX/MEM, MEM/WB.
* ONE single-ported, byte-addressable, little-endian 4 KB memory for both
  instructions and data (0x000-0x3FF program, 0x400-0xFFF data).
* Structural hazard: an instruction is issued every other cycle. A 1-bit
  'phase' register toggles every cycle; phase 0 (C0) gives the memory to IF,
  phase 1 (C1) gives it to MEM. IF/ID receives a NOP on C1 cycles.
  Effective CPI = 2 (plus 2 cycles per taken branch/jump).
* Data hazards: forwarding unit (EX/MEM and MEM/WB -> EX). Because a bubble
  always separates two instructions, the producer is in WB when the consumer
  is in EX, so MEM/WB forwarding resolves every RAW hazard, including
  load-use. No stall is ever needed.
* Control hazards: branches/JAL/JALR resolved in EX, applied in MEM (a C1
  cycle): PC <- target and ID/EX is zeroed (flush of the single wrong-path
  instruction).
* EBREAK: when fetched, the PC register is not loaded, so the CPU keeps
  re-fetching EBREAK forever. A taken branch ahead of a wrong-path EBREAK
  still overrides the PC (verified in test 3).

Bonus features
--------------
1. RV32M (bonus 2): MUL, MULH, MULHSU, MULHU, DIV, DIVU, REM, REMU, including
   the divide-by-zero and overflow corner cases from the specification.
2. Random test program generator (bonus 6): tools/gen_random.py generates
   random valid, always-terminating programs with dense hazards; run_tests.py
   checks each one against the golden model.

How to run the tests (simulation)
---------------------------------
Requires Python 3 and Icarus Verilog:
    python3 tools/run_tests.py              # 5 directed tests
    python3 tools/run_tests.py --random 50  # + 50 random programs
Each test is assembled, run on the golden model (iss.py) and on the Verilog,
and the full register file + data memory are compared.
In Vivado: add Verilog/*.v (except Top.v for simulation) and test/tb_femtoRV32.v,
add the .hex file as a simulation source and set the HEXFILE define or
rename it to program.hex.

Test programs
-------------
t1_all_instructions   every RV32I instruction, each branch taken + not taken
t2_data_hazards       ALU->ALU (rs1, rs2, both), chains, x0 not forwarded,
                      ALU/load -> store data and address, load-use,
                      load -> load address, ALU/load -> branch, ALU -> JALR,
                      JAL link -> use, LUI/AUIPC -> use
t3_control_hazards    flush after taken branch (wrong-path register write,
                      store and EBREAK), back-to-back branches, branch to
                      branch, not-taken branch, JALR flush, backward loop
t4_special_and_halt   ECALL/FENCE/FENCE.TSO/PAUSE as no-ops, EBREAK halt,
                      nothing after EBREAK executes
t5_rv32m_bonus        all RV32M instructions + corner cases
Results: all 5 directed tests and 50 random programs pass.

FPGA usage (Nexys A7)
---------------------
BTNR = CPU clock (1 press = 1 cycle = half an instruction), BTNC = reset
SW[1:0]  ledSel : 00 instruction[15:0], 01 instruction[31:16],
                  10 {phase, halted, flush, forwardA, forwardB, Branch, Jump,
                      JumpReg, MemRead, MemWrite, ALUSrc, RegWrite, WBSel}
                  11 {ID/EX.rd, EX/MEM.rd, MEM/WB.rd, MEM/WB.RegWrite}
SW[5:2]  ssdSel : 0 PC, 1 IF/ID.PC, 2 ID/EX.PC, 3 branch target,
                  4 ReadData1, 5 ReadData2, 6 Immediate, 7 ALU in1, 8 ALU in2,
                  9 ALU result, 10 memory out, 11 write-back data,
                  12 register selected by SW[10:6], 13 cycle counter,
                  14 EX/MEM ALU result (memory address)
To check results after the program halts: ssdSel = 1100 and select the
register with SW[10:6].

Assumptions / known limitations
-------------------------------
* Misaligned loads/stores are performed byte by byte (no exception).
* Memory addresses wrap at 4 KB (only address bits [11:0] are used).
* The CPU clock is a debounced push button, so the design is not
  timing-constrained for 100 MHz operation of the core (the divider in the
  RV32M ALU is a long combinational path).
* FPGA testing: ______ (fill in after testing on the board)
