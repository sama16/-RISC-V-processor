#!/usr/bin/env python3
"""
run_tests.py - regression runner.

For every test/*.s (or the files given on the command line):
  1. assemble it with rvasm.py           -> test/<name>.hex, test/<name>.lst
  2. run the golden model iss.py         -> test/results/<name>.expected
  3. simulate the Verilog with Icarus    -> test/results/<name>.sim
  4. compare register file + data memory -> PASS / FAIL

Options:
  --random N    also generate and check N random programs (gen_random.py)
  --vcd         also dump a waveform for each test

Run from the project root:   python3 tools/run_tests.py [--random 50]
"""
import argparse
import glob
import os
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, 'tools'))
import rvasm          # noqa: E402
import iss            # noqa: E402

RESULTS = os.path.join(ROOT, 'test', 'results')
SIM_BIN = os.path.join(RESULTS, 'sim.vvp')


def verilog_sources():
    srcs = sorted(glob.glob(os.path.join(ROOT, 'Verilog', '*.v')))
    srcs = [s for s in srcs if os.path.basename(s) not in ('Top.v', 'Debouncer.v')]
    return srcs + [os.path.join(ROOT, 'test', 'tb_femtoRV32.v')]


def run_one(asm_path, vcd=False):
    name = os.path.splitext(os.path.basename(asm_path))[0]
    base = os.path.splitext(asm_path)[0]
    hexf, lst = base + '.hex', base + '.lst'
    mem, listing, _ = rvasm.assemble(open(asm_path).read())
    rvasm.write_hex(mem, hexf)
    rvasm.write_listing(listing, lst)

    ref = iss.ISS(mem)
    if not ref.run():
        return name, False, "golden model did not halt"
    expected = ref.dump()
    open(os.path.join(RESULTS, name + '.expected'), 'w').write(expected)

    simout = os.path.join(RESULTS, name + '.sim')
    subprocess.run(['iverilog', '-g2005', f'-DHEXFILE="{hexf}"', '-o', SIM_BIN]
                   + verilog_sources(), check=True, capture_output=True)
    args = ['vvp', '-n', SIM_BIN, f'+OUT={simout}'] + (['+VCD'] if vcd else [])
    r = subprocess.run(args, capture_output=True, text=True, check=True)
    actual = open(simout).read()

    cycles_line = [l for l in r.stdout.splitlines() if l.startswith('halted')]
    info = cycles_line[0] if cycles_line else r.stdout.strip()
    info += f" | retired={ref.retired} taken={ref.taken}"
    if 'TIMEOUT' in r.stdout:
        return name, False, "TIMEOUT " + info
    if expected != actual:
        exp, act = expected.splitlines(), actual.splitlines()
        diffs = [f"   expected {e!r:24} got {a!r}" for e, a in zip(exp, act) if e != a]
        if len(exp) != len(act):
            diffs.append(f"   line count expected {len(exp)} got {len(act)}")
        return name, False, info + "\n" + "\n".join(diffs[:10])
    return name, True, info


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('files', nargs='*')
    ap.add_argument('--random', type=int, default=0)
    ap.add_argument('--seed', type=int, default=1)
    ap.add_argument('--vcd', action='store_true')
    a = ap.parse_args()
    os.makedirs(RESULTS, exist_ok=True)

    files = a.files or sorted(glob.glob(os.path.join(ROOT, 'test', 't*.s')))
    if a.random:
        import gen_random
        rdir = os.path.join(ROOT, 'test', 'random')
        os.makedirs(rdir, exist_ok=True)
        for k in range(a.random):
            path = os.path.join(rdir, f'rand_{a.seed + k:04d}.s')
            open(path, 'w').write(gen_random.generate(seed=a.seed + k))
            files.append(path)

    fails = 0
    for f in files:
        name, ok, info = run_one(f, a.vcd)
        print(f"[{'PASS' if ok else 'FAIL'}] {name:28s} {info}")
        fails += not ok
    print(f"\n{len(files) - fails}/{len(files)} passed")
    sys.exit(1 if fails else 0)


if __name__ == '__main__':
    main()
