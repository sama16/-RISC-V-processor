#!/usr/bin/env python3
"""
rvasm.py - minimal RV32I + RV32M assembler for the femtoRV32 project.

Usage:
    python3 rvasm.py program.s -o program.hex [-l program.lst]

Output (.hex) is one byte per line (little endian), suitable for
$readmemh into the byte-addressable unified Memory module.

Supported syntax
    label:                      labels (on their own line or before an instruction)
    # comment / // comment      comments
    .org  ADDR                  move the location counter (e.g. .org 0x400 for data)
    .word V [, V ...]           32-bit data words
    add x1, x2, x3              R-type   (ABI names like a0, sp, t1 also work)
    addi x1, x2, -5             I-type
    lw x1, 8(x2)  /  sw x2, -4(x3)
    beq x1, x2, label           branches / jal accept labels or numeric offsets
    jal x1, label   jal label   jalr x1, 0(x2)   jalr x1, x2, 0
    lui x1, 0x12345   auipc x1, 0
    ecall ebreak fence fence.tso pause nop
    li rd, imm                  pseudo: expands to lui+addi (always 2 instructions)
    mv rd, rs / j label         pseudo
"""
import re
import sys
import argparse

ABI = {
    'zero': 0, 'ra': 1, 'sp': 2, 'gp': 3, 'tp': 4, 't0': 5, 't1': 6, 't2': 7,
    's0': 8, 'fp': 8, 's1': 9, 'a0': 10, 'a1': 11, 'a2': 12, 'a3': 13,
    'a4': 14, 'a5': 15, 'a6': 16, 'a7': 17, 's2': 18, 's3': 19, 's4': 20,
    's5': 21, 's6': 22, 's7': 23, 's8': 24, 's9': 25, 's10': 26, 's11': 27,
    't3': 28, 't4': 29, 't5': 30, 't6': 31,
}

R_OPS = {  # name: (funct7, funct3)
    'add': (0x00, 0), 'sub': (0x20, 0), 'sll': (0x00, 1), 'slt': (0x00, 2),
    'sltu': (0x00, 3), 'xor': (0x00, 4), 'srl': (0x00, 5), 'sra': (0x20, 5),
    'or': (0x00, 6), 'and': (0x00, 7),
    'mul': (0x01, 0), 'mulh': (0x01, 1), 'mulhsu': (0x01, 2), 'mulhu': (0x01, 3),
    'div': (0x01, 4), 'divu': (0x01, 5), 'rem': (0x01, 6), 'remu': (0x01, 7),
}
I_ALU = {'addi': 0, 'slti': 2, 'sltiu': 3, 'xori': 4, 'ori': 6, 'andi': 7}
I_SHIFT = {'slli': (0x00, 1), 'srli': (0x00, 5), 'srai': (0x20, 5)}
LOADS = {'lb': 0, 'lh': 1, 'lw': 2, 'lbu': 4, 'lhu': 5}
STORES = {'sb': 0, 'sh': 1, 'sw': 2}
BRANCHES = {'beq': 0, 'bne': 1, 'blt': 4, 'bge': 5, 'bltu': 6, 'bgeu': 7}
FIXED = {
    'ecall': 0x00000073, 'ebreak': 0x00100073, 'fence': 0x0FF0000F,
    'fence.tso': 0x8330000F, 'pause': 0x0100000F, 'nop': 0x00000013,
}


class AsmError(Exception):
    pass


def reg(tok):
    tok = tok.strip().lower()
    if tok in ABI:
        return ABI[tok]
    m = re.fullmatch(r'x(\d+)', tok)
    if m and 0 <= int(m.group(1)) < 32:
        return int(m.group(1))
    raise AsmError(f"bad register '{tok}'")


def num(tok):
    return int(tok.strip(), 0)


def check_range(v, bits, signed=True, what='immediate'):
    lo, hi = (-(1 << (bits - 1)), (1 << (bits - 1)) - 1) if signed else (0, (1 << bits) - 1)
    if not lo <= v <= hi:
        raise AsmError(f"{what} {v} out of range [{lo}, {hi}]")


def enc_r(f7, rs2, rs1, f3, rd, op):
    return (f7 << 25) | (rs2 << 20) | (rs1 << 15) | (f3 << 12) | (rd << 7) | op


def enc_i(imm, rs1, f3, rd, op):
    check_range(imm, 12)
    return ((imm & 0xFFF) << 20) | (rs1 << 15) | (f3 << 12) | (rd << 7) | op


def enc_s(imm, rs2, rs1, f3, op):
    check_range(imm, 12)
    imm &= 0xFFF
    return ((imm >> 5) << 25) | (rs2 << 20) | (rs1 << 15) | (f3 << 12) | ((imm & 0x1F) << 7) | op


def enc_b(off, rs2, rs1, f3):
    check_range(off, 13, what='branch offset')
    if off & 1:
        raise AsmError("branch offset must be even")
    o = off & 0x1FFF
    return (((o >> 12) & 1) << 31) | (((o >> 5) & 0x3F) << 25) | (rs2 << 20) | (rs1 << 15) | \
           (f3 << 12) | (((o >> 1) & 0xF) << 8) | (((o >> 11) & 1) << 7) | 0x63


def enc_u(imm20, rd, op):
    check_range(imm20, 20, signed=False, what='upper immediate')
    return (imm20 << 12) | (rd << 7) | op


def enc_j(off, rd):
    check_range(off, 21, what='jump offset')
    if off & 1:
        raise AsmError("jump offset must be even")
    o = off & 0x1FFFFF
    return (((o >> 20) & 1) << 31) | (((o >> 1) & 0x3FF) << 21) | (((o >> 11) & 1) << 20) | \
           (((o >> 12) & 0xFF) << 12) | (rd << 7) | 0x6F


def split_operands(s):
    return [t.strip() for t in s.split(',')] if s.strip() else []


def mem_operand(tok):
    m = re.fullmatch(r'\s*(-?[\w]+)?\s*\(\s*(\w+)\s*\)\s*', tok)
    if not m:
        raise AsmError(f"bad memory operand '{tok}'")
    off = num(m.group(1)) if m.group(1) else 0
    return off, reg(m.group(2))


def li_parts(value):
    """Split a 32-bit constant into (upper20, lower12) for lui+addi."""
    value &= 0xFFFFFFFF
    lo = value & 0xFFF
    if lo >= 0x800:
        lo -= 0x1000
    hi = ((value - lo) >> 12) & 0xFFFFF
    return hi, lo


def strip_comment(line):
    line = line.split('#')[0]
    line = line.split('//')[0]
    return line.strip()


def first_pass(lines):
    """Return list of (addr, mnemonic, operands, source_line) and the label table."""
    labels, items, pc = {}, [], 0
    for lineno, raw in enumerate(lines, 1):
        line = strip_comment(raw)
        while True:
            m = re.match(r'^([A-Za-z_.][\w.]*)\s*:\s*(.*)$', line)
            if not m:
                break
            if m.group(1) in labels:
                raise AsmError(f"line {lineno}: duplicate label {m.group(1)}")
            labels[m.group(1)] = pc
            line = m.group(2).strip()
        if not line:
            continue
        parts = line.split(None, 1)
        mnem = parts[0].lower()
        ops = parts[1] if len(parts) > 1 else ''
        if mnem == '.org':
            pc = num(ops)
            continue
        if mnem == '.word':
            for v in split_operands(ops):
                items.append((pc, '.word', v, raw.rstrip(), lineno))
                pc += 4
            continue
        size = 8 if mnem == 'li' else 4
        items.append((pc, mnem, ops, raw.rstrip(), lineno))
        pc += size
    return items, labels


def target(tok, labels, pc):
    tok = tok.strip()
    if tok in labels:
        return labels[tok] - pc
    return num(tok)


def assemble_one(pc, mnem, ops, labels):
    o = split_operands(ops)
    if mnem in FIXED:
        return [FIXED[mnem]]
    if mnem == '.word':
        v = labels[ops] if ops in labels else num(ops)
        return [v & 0xFFFFFFFF]
    if mnem in R_OPS:
        f7, f3 = R_OPS[mnem]
        return [enc_r(f7, reg(o[2]), reg(o[1]), f3, reg(o[0]), 0x33)]
    if mnem in I_ALU:
        return [enc_i(num(o[2]), reg(o[1]), I_ALU[mnem], reg(o[0]), 0x13)]
    if mnem in I_SHIFT:
        f7, f3 = I_SHIFT[mnem]
        sh = num(o[2])
        check_range(sh, 5, signed=False, what='shift amount')
        return [enc_r(f7, sh, reg(o[1]), f3, reg(o[0]), 0x13)]
    if mnem in LOADS:
        off, rs1 = mem_operand(o[1])
        return [enc_i(off, rs1, LOADS[mnem], reg(o[0]), 0x03)]
    if mnem in STORES:
        off, rs1 = mem_operand(o[1])
        return [enc_s(off, reg(o[0]), rs1, STORES[mnem], 0x23)]
    if mnem in BRANCHES:
        return [enc_b(target(o[2], labels, pc), reg(o[1]), reg(o[0]), BRANCHES[mnem])]
    if mnem == 'jal':
        if len(o) == 1:
            return [enc_j(target(o[0], labels, pc), 1)]
        return [enc_j(target(o[1], labels, pc), reg(o[0]))]
    if mnem == 'j':
        return [enc_j(target(o[0], labels, pc), 0)]
    if mnem == 'jalr':
        if len(o) == 2:
            off, rs1 = mem_operand(o[1])
        else:
            rs1, off = reg(o[1]), num(o[2])
        return [enc_i(off, rs1, 0, reg(o[0]), 0x67)]
    if mnem == 'lui':
        return [enc_u(num(o[1]) & 0xFFFFF if num(o[1]) < 0 else num(o[1]), reg(o[0]), 0x37)]
    if mnem == 'auipc':
        return [enc_u(num(o[1]) & 0xFFFFF if num(o[1]) < 0 else num(o[1]), reg(o[0]), 0x17)]
    if mnem == 'li':
        hi, lo = li_parts(num(o[1]))
        rd = reg(o[0])
        return [enc_u(hi, rd, 0x37), enc_i(lo, rd, 0, rd, 0x13)]
    if mnem == 'mv':
        return [enc_i(0, reg(o[1]), 0, reg(o[0]), 0x13)]
    raise AsmError(f"unknown instruction '{mnem}'")


def assemble(text, mem_size=4096):
    items, labels = first_pass(text.splitlines())
    mem = bytearray(mem_size)
    listing = []
    for pc, mnem, ops, src, lineno in items:
        try:
            words = assemble_one(pc, mnem, ops, labels)
        except (AsmError, ValueError, IndexError) as e:
            raise AsmError(f"line {lineno}: {src.strip()} -> {e}")
        for k, w in enumerate(words):
            a = pc + 4 * k
            if a + 4 > mem_size:
                raise AsmError(f"line {lineno}: address 0x{a:x} outside memory")
            mem[a:a + 4] = w.to_bytes(4, 'little')
            listing.append((a, w, src.strip() if k == 0 else '    (cont.)'))
    return mem, listing, labels


def write_hex(mem, path):
    with open(path, 'w') as f:
        for b in mem:
            f.write(f"{b:02x}\n")


def write_listing(listing, path):
    with open(path, 'w') as f:
        for a, w, src in listing:
            f.write(f"{a:04x}:  {w:08x}    {src}\n")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('src')
    ap.add_argument('-o', '--out', required=True)
    ap.add_argument('-l', '--listing')
    a = ap.parse_args()
    with open(a.src) as f:
        mem, listing, _ = assemble(f.read())
    write_hex(mem, a.out)
    if a.listing:
        write_listing(listing, a.listing)


if __name__ == '__main__':
    try:
        main()
    except AsmError as e:
        sys.exit(f"rvasm: {e}")
