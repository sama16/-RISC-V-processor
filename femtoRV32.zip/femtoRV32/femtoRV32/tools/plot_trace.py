#!/usr/bin/env python3
"""
plot_trace.py - turn the output of tb_trace.v into
  * a waveform-style PNG (pipeline stages labelled with assembly text)
  * a cycle-by-cycle text table

Usage: python3 plot_trace.py trace.txt program.lst out_prefix [start] [count]
"""
import sys
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon


def load_listing(path):
    """address -> assembly text (labels removed)"""
    m = {}
    for line in open(path):
        parts = line.split(None, 2)
        if len(parts) >= 2 and parts[0].endswith(':'):
            addr = int(parts[0][:-1], 16)
            src = parts[2].strip() if len(parts) > 2 else ''
            src = src.split('#')[0].strip()
            if src and ':' in src.split()[0]:
                src = src.split(':', 1)[1].strip()
            m[addr] = src
    return m


def short(m, field):
    """field = 'INST:PC'; bubbles (NOP or zero) are shown as 'bubble'."""
    inst, pc = field.split(':')
    if inst in ('00000013', '00000000'):
        return 'bubble'
    return m.get(int(pc, 16) & 0xFFFFFFFF, inst)


def main():
    trace, lst, out = sys.argv[1], sys.argv[2], sys.argv[3]
    start = int(sys.argv[4]) if len(sys.argv) > 4 else 0
    count = int(sys.argv[5]) if len(sys.argv) > 5 else 24
    asm = load_listing(lst)
    rows = []
    for line in open(trace):
        f = line.split()
        if len(f) == 14 and f[0].isdigit():
            rows.append(f)
    rows = rows[start:start + count]

    # ---------------- text table ----------------
    with open(out + '.txt', 'w') as t:
        hdr = f"{'cyc':>3} {'ph':>2} {'PC':>4} | {'ID':22} | {'EX':22} | {'MEM':22} | {'WB':22} | fA fB flush halt | write-back"
        t.write(hdr + '\n' + '-' * len(hdr) + '\n')
        for r in rows:
            wb = f"x{int(r[12])} <= 0x{r[13]}" if r[11] == '1' and r[12] != '0' else ''
            t.write(f"{r[0]:>3} {('C1' if r[1] == '1' else 'C0'):>2} {int(r[2], 16):>4x} | "
                    f"{short(asm, r[3])[:22]:22} | {short(asm, r[4])[:22]:22} | "
                    f"{short(asm, r[5])[:22]:22} | {short(asm, r[6])[:22]:22} | "
                    f"{r[7]:>2} {r[8]:>2} {r[9]:>5} {r[10]:>4} | {wb}\n")

    # ---------------- waveform ----------------
    n = len(rows)
    lanes = [('phase (C0/C1)', 'bit', 1), ('PC', 'bus', 2), ('ID  (IF/ID)', 'bus', 3),
             ('EX  (ID/EX)', 'bus', 4), ('MEM (EX/MEM)', 'bus', 5), ('WB  (MEM/WB)', 'bus', 6),
             ('forwardA', 'bus', 7), ('forwardB', 'bus', 8), ('flush (redirect)', 'bit', 9),
             ('halted', 'bit', 10), ('write-back', 'bus', 'wb')]
    h = 0.6
    fig, ax = plt.subplots(figsize=(max(14, n * 1.05), 0.75 * len(lanes) + 1))
    for li, (name, kind, col) in enumerate(lanes):
        y = (len(lanes) - 1 - li) * 1.0
        ax.text(-0.3, y + h / 2, name, ha='right', va='center', fontsize=9, family='monospace')
        prev = None
        for c, r in enumerate(rows):
            if kind == 'bit':
                v = int(r[col])
                ax.plot([c, c + 1], [y + v * h] * 2, color='tab:blue', lw=1.6)
                if prev is not None and prev != v:
                    ax.plot([c, c], [y, y + h], color='tab:blue', lw=1.6)
                prev = v
            else:
                if col == 'wb':
                    label = f"x{int(r[12])}={int(r[13], 16) if int(r[13], 16) < 1 << 31 else int(r[13], 16) - (1 << 32)}" \
                        if r[11] == '1' and r[12] != '0' else ''
                elif col == 2:
                    label = f"{int(r[2], 16):x}"
                elif col in (7, 8):
                    label = {'0': '', '1': 'MEM/WB', '2': 'EX/MEM'}[r[col]]
                else:
                    label = short(asm, r[col])
                    label = '' if label == 'bubble' else label
                color = '#dbeafe' if label else '#f3f4f6'
                if col in (7, 8) and label:
                    color = '#bbf7d0'
                if col == 'wb' and label:
                    color = '#fde68a'
                d = 0.08
                poly = Polygon([[c + d, y], [c, y + h / 2], [c + d, y + h], [c + 1 - d, y + h],
                                [c + 1, y + h / 2], [c + 1 - d, y]], closed=True,
                               facecolor=color, edgecolor='#555', lw=0.7)
                ax.add_patch(poly)
                if label:
                    ax.text(c + 0.5, y + h / 2, label, ha='center', va='center',
                            fontsize=6.5 if len(label) > 11 else 7.5, family='monospace')
    for c, r in enumerate(rows):
        ax.text(c + 0.5, len(lanes) - 0.25, r[0], ha='center', fontsize=7, color='#666')
        ax.axvline(c, color='#e5e7eb', lw=0.5, zorder=0)
    ax.text(-0.3, len(lanes) - 0.25, 'cycle', ha='right', fontsize=8, color='#666')
    ax.set_xlim(-0.1, n + 0.1)
    ax.set_ylim(-0.3, len(lanes) + 0.1)
    ax.axis('off')
    plt.tight_layout()
    plt.savefig(out + '.png', dpi=150, bbox_inches='tight')


if __name__ == '__main__':
    main()
