#!/usr/bin/env python3
"""
iss.py - golden reference instruction-set simulator (RV32I + RV32M) used to
check the Verilog pipeline. It runs the same byte-per-line .hex image as the
hardware, from PC = 0 until EBREAK, with the project's special rules:
EBREAK halts, ECALL / FENCE / FENCE.TSO / PAUSE are no-ops.

Usage:  python3 iss.py program.hex [-o expected.txt] [-t]   (-t = trace)
Output format (same as the testbench dump):
    x1  0000002a
    ...
    mem 0400 deadbeef      (every non-zero data word from 0x400 to 0xFFF)
"""
import sys
import argparse

MASK = 0xFFFFFFFF


def sx(v, bits):
    v &= (1 << bits) - 1
    return v - (1 << bits) if v >> (bits - 1) else v


def s32(v):
    return sx(v, 32)


class ISS:
    def __init__(self, mem):
        self.mem = bytearray(mem)
        self.x = [0] * 32
        self.pc = 0
        self.retired = 0
        self.taken = 0          # taken branches + jumps (each costs one flushed slot)

    def load(self, a, n, signed):
        v = int.from_bytes(self.mem[a:a + n], 'little')
        return sx(v, 8 * n) & MASK if signed else v

    def store(self, a, n, v):
        self.mem[a:a + n] = (v & ((1 << (8 * n)) - 1)).to_bytes(n, 'little')

    def step(self):
        pc = self.pc
        inst = int.from_bytes(self.mem[pc:pc + 4], 'little')
        if inst == 0x00100073:          # EBREAK -> halt
            return False
        op = inst & 0x7F
        rd = (inst >> 7) & 0x1F
        f3 = (inst >> 12) & 7
        rs1 = (inst >> 15) & 0x1F
        rs2 = (inst >> 20) & 0x1F
        f7 = inst >> 25
        a, b = self.x[rs1], self.x[rs2]
        imm_i = sx(inst >> 20, 12)
        imm_s = sx(((inst >> 25) << 5) | ((inst >> 7) & 0x1F), 12)
        imm_b = sx((((inst >> 31) & 1) << 12) | (((inst >> 7) & 1) << 11) |
                   (((inst >> 25) & 0x3F) << 5) | (((inst >> 8) & 0xF) << 1), 13)
        imm_u = inst & 0xFFFFF000
        imm_j = sx((((inst >> 31) & 1) << 20) | (((inst >> 12) & 0xFF) << 12) |
                   (((inst >> 20) & 1) << 11) | (((inst >> 21) & 0x3FF) << 1), 21)
        next_pc = (pc + 4) & MASK
        res = None

        def alu(f3, f7, a, b, is_imm):
            sh = b & 0x1F
            if not is_imm and f7 == 0x01:
                return self.muldiv(f3, a, b)
            if f3 == 0:
                return (a - b) if (not is_imm and f7 == 0x20) else (a + b)
            if f3 == 1:
                return a << sh
            if f3 == 2:
                return int(s32(a) < s32(b))
            if f3 == 3:
                return int((a & MASK) < (b & MASK))
            if f3 == 4:
                return a ^ b
            if f3 == 5:
                return (s32(a) >> sh) if f7 == 0x20 else ((a & MASK) >> sh)
            if f3 == 6:
                return a | b
            return a & b

        if op == 0x33:
            res = alu(f3, f7, a, b, False)
        elif op == 0x13:
            res = alu(f3, f7 if f3 == 5 else 0, a, imm_i & MASK, True)
        elif op == 0x03:
            addr = (a + imm_i) & 0xFFF
            n = {0: 1, 1: 2, 2: 4, 4: 1, 5: 2}[f3]
            res = self.load(addr, n, f3 in (0, 1))
        elif op == 0x23:
            addr = (a + imm_s) & 0xFFF
            self.store(addr, {0: 1, 1: 2, 2: 4}[f3], b)
        elif op == 0x63:
            cond = {0: a == b, 1: a != b, 4: s32(a) < s32(b), 5: s32(a) >= s32(b),
                    6: a < b, 7: a >= b}.get(f3, False)
            if cond:
                next_pc = (pc + imm_b) & MASK
                self.taken += 1
        elif op == 0x6F:
            res = pc + 4
            next_pc = (pc + imm_j) & MASK
            self.taken += 1
        elif op == 0x67:
            res = pc + 4
            next_pc = (a + imm_i) & MASK & ~1
            self.taken += 1
        elif op == 0x37:
            res = imm_u
        elif op == 0x17:
            res = pc + imm_u
        # 0x0F (FENCE/PAUSE/FENCE.TSO) and 0x73 (ECALL): no-operation
        if res is not None and rd != 0:
            self.x[rd] = res & MASK
        self.pc = next_pc
        self.retired += 1
        return True

    @staticmethod
    def muldiv(f3, a, b):
        sa, sb = s32(a), s32(b)
        if f3 == 0:
            return (sa * sb) & MASK
        if f3 == 1:
            return ((sa * sb) >> 32) & MASK
        if f3 == 2:
            return ((sa * b) >> 32) & MASK
        if f3 == 3:
            return ((a * b) >> 32) & MASK
        if f3 == 4:
            if b == 0:
                return MASK
            if sa == -2**31 and sb == -1:
                return 0x80000000
            q = abs(sa) // abs(sb)
            return (q if (sa < 0) == (sb < 0) else -q) & MASK
        if f3 == 5:
            return MASK if b == 0 else a // b
        if f3 == 6:
            if b == 0:
                return a
            if sa == -2**31 and sb == -1:
                return 0
            r = abs(sa) % abs(sb)
            return (r if sa >= 0 else -r) & MASK
        return a if b == 0 else a % b

    def run(self, max_steps=200000, trace=False):
        while self.retired < max_steps:
            pc = self.pc
            if trace:
                inst = int.from_bytes(self.mem[pc:pc + 4], 'little')
                print(f"pc={pc:04x} inst={inst:08x}")
            if not self.step():
                return True
        return False

    def dump(self):
        lines = [f"x{i:<2d} {self.x[i]:08x}" for i in range(1, 32)]
        for a in range(0x400, len(self.mem), 4):
            w = int.from_bytes(self.mem[a:a + 4], 'little')
            if w:
                lines.append(f"mem {a:04x} {w:08x}")
        return "\n".join(lines) + "\n"


def load_hex(path, size=4096):
    mem = bytearray(size)
    with open(path) as f:
        vals = [l.strip() for l in f if l.strip() and not l.startswith('//')]
    for i, v in enumerate(vals[:size]):
        mem[i] = int(v, 16)
    return mem


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('hex')
    ap.add_argument('-o', '--out')
    ap.add_argument('-t', '--trace', action='store_true')
    a = ap.parse_args()
    sim = ISS(load_hex(a.hex))
    if not sim.run(trace=a.trace):
        sys.exit("iss: program did not reach EBREAK")
    text = sim.dump()
    if a.out:
        open(a.out, 'w').write(text)
    else:
        sys.stdout.write(text)
    # expected pipeline cycles: 2 per instruction + 2 per taken branch/jump
    print(f"# retired={sim.retired} taken={sim.taken}", file=sys.stderr)


if __name__ == '__main__':
    main()
