#!/usr/bin/env python3
"""
gen_random.py - random test-program generator (Bonus feature 6).

Generates random but VALID RV32I(+M) assembly programs that always terminate,
assembles them to machine code, and (optionally) prints the expected final
state from the golden model.

Design of the generated programs
  * x31 is reserved as the data base pointer (0x400) and is never overwritten,
    so every load/store hits the data region with a correctly aligned offset.
  * Destination/source registers are biased toward recently written registers
    so that read-after-write hazards (incl. load-use and store-data) are dense.
  * Branches and JAL only jump FORWARD over a few instructions, and JALR is
    produced as "auipc t, 0 ; jalr rd, K(t)" with a forward K, so the program
    can never loop forever and never jumps into data.
  * Every special instruction (ECALL, FENCE, FENCE.TSO, PAUSE) appears randomly;
    the program ends with EBREAK, followed by a "poison" instruction that must
    never execute.

Usage:
    python3 gen_random.py -n 120 --seed 7 -o rand.s [--hex rand.hex] [--expected]
"""
import argparse
import random
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import rvasm   # noqa: E402
import iss     # noqa: E402

R_OPS = ['add', 'sub', 'sll', 'slt', 'sltu', 'xor', 'srl', 'sra', 'or', 'and']
M_OPS = ['mul', 'mulh', 'mulhsu', 'mulhu', 'div', 'divu', 'rem', 'remu']
I_OPS = ['addi', 'slti', 'sltiu', 'xori', 'ori', 'andi']
SH_OPS = ['slli', 'srli', 'srai']
LOADS = {'lb': 1, 'lh': 2, 'lw': 4, 'lbu': 1, 'lhu': 2}
STORES = {'sb': 1, 'sh': 2, 'sw': 4}
BRANCHES = ['beq', 'bne', 'blt', 'bge', 'bltu', 'bgeu']
SPECIAL = ['ecall', 'fence', 'fence.tso', 'pause']

BASE = 31            # data pointer register
DATA_BYTES = 256     # random accesses stay inside 0x400 .. 0x4FF


class Gen:
    def __init__(self, seed, use_m=True):
        self.r = random.Random(seed)
        self.recent = [1, 2, 3]
        self.use_m = use_m
        self.label_id = 0
        self.lines = []

    def rd(self):
        # avoid x31; sometimes write x0 to test that it stays zero
        if self.r.random() < 0.03:
            return 0
        d = self.r.randint(1, 30)
        self.recent = ([d] + self.recent)[:4]
        return d

    def rs(self):
        # 70 %: a recently written register -> RAW hazard
        if self.r.random() < 0.7:
            return self.r.choice(self.recent)
        return self.r.randint(0, 30)

    def imm12(self):
        return self.r.choice([0, 1, -1, 2047, -2048, self.r.randint(-2048, 2047)])

    def label(self):
        self.label_id += 1
        return f"L{self.label_id}"

    def emit(self, s):
        self.lines.append("        " + s)

    def simple(self):
        """One instruction that does not change control flow."""
        k = self.r.random()
        if k < 0.25:
            ops = R_OPS + (M_OPS if self.use_m else [])
            a, b = self.rs(), self.rs()
            self.emit(f"{self.r.choice(ops)} x{self.rd()}, x{a}, x{b}")
        elif k < 0.45:
            a = self.rs()
            self.emit(f"{self.r.choice(I_OPS)} x{self.rd()}, x{a}, {self.imm12()}")
        elif k < 0.52:
            a = self.rs()
            self.emit(f"{self.r.choice(SH_OPS)} x{self.rd()}, x{a}, {self.r.randint(0, 31)}")
        elif k < 0.57:
            self.emit(f"lui x{self.rd()}, {hex(self.r.randint(0, 0xFFFFF))}")
        elif k < 0.60:
            self.emit(f"auipc x{self.rd()}, {hex(self.r.randint(0, 0xFFFFF))}")
        elif k < 0.76:
            op = self.r.choice(list(LOADS))
            off = self.r.randrange(0, DATA_BYTES, LOADS[op])
            self.emit(f"{op} x{self.rd()}, {off}(x{BASE})")
        elif k < 0.92:
            op = self.r.choice(list(STORES))
            off = self.r.randrange(0, DATA_BYTES, STORES[op])
            self.emit(f"{op} x{self.rs()}, {off}(x{BASE})")
        else:
            self.emit(self.r.choice(SPECIAL))

    def control(self):
        """A forward branch / jal / jalr that skips 0-3 instructions."""
        skip = self.r.randint(0, 3)
        k = self.r.random()
        if k < 0.6:
            lab = self.label()
            a, b = self.rs(), self.rs()
            self.emit(f"{self.r.choice(BRANCHES)} x{a}, x{b}, {lab}")
            for _ in range(skip):
                self.simple()
            self.lines.append(f"{lab}:")
        elif k < 0.8:
            lab = self.label()
            self.emit(f"jal x{self.rd()}, {lab}")
            for _ in range(skip):
                self.simple()
            self.lines.append(f"{lab}:")
        else:
            t = self.r.randint(1, 30)          # never x0 (auipc x0 would lose the PC)
            self.recent = ([t] + self.recent)[:4]
            link = self.rd()
            # auipc t,0 is at address A; jalr is at A+4; target = A+8+4*skip
            self.emit(f"auipc x{t}, 0")
            self.emit(f"jalr x{link}, {8 + 4 * skip}(x{t})")
            for _ in range(skip):
                self.simple()

    def program(self, n):
        self.lines.append(f"# random program, generated by gen_random.py")
        self.emit(f"addi x{BASE}, x0, 0x400       # reserved data pointer")
        for d in (1, 2, 3, 4, 5):
            self.emit(f"addi x{d}, x0, {self.imm12()}")
        while len(self.lines) < n:
            if self.r.random() < 0.18:
                self.control()
            else:
                self.simple()
        self.emit("ebreak")
        self.emit("addi x1, x0, 1234      # poison: must never execute")
        self.lines.append("        .org 0x400")
        for i in range(DATA_BYTES // 4):
            self.lines.append(f"        .word {hex(self.r.getrandbits(32))}")
        return "\n".join(self.lines) + "\n"


def generate(seed=1, n=150, use_m=True):
    return Gen(seed, use_m).program(n)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('-n', type=int, default=150, help='approximate instruction count (<240)')
    ap.add_argument('--seed', type=int, default=1)
    ap.add_argument('--no-m', action='store_true', help='RV32I only (no mul/div)')
    ap.add_argument('-o', '--out', default='-')
    ap.add_argument('--hex')
    ap.add_argument('--expected', action='store_true')
    a = ap.parse_args()
    text = generate(a.seed, min(a.n, 240), not a.no_m)
    if a.out == '-':
        sys.stdout.write(text)
    else:
        open(a.out, 'w').write(text)
    mem, listing, _ = rvasm.assemble(text)
    if a.hex:
        rvasm.write_hex(mem, a.hex)
        rvasm.write_listing(listing, os.path.splitext(a.hex)[0] + '.lst')
    if a.expected:
        sim = iss.ISS(mem)
        sim.run()
        sys.stderr.write(sim.dump())


if __name__ == '__main__':
    main()
