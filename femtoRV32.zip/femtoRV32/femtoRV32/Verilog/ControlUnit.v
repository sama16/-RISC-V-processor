`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Module Name: ControlUnit
// Description: Main decoder (opcode -> datapath control signals).
//              The default for every opcode is "all signals 0", which is a
//              no-operation. FENCE / FENCE.TSO / PAUSE (opcode 0001111) and
//              ECALL / EBREAK (opcode 1110011) therefore act as NOPs here;
//              EBREAK's halting behaviour is implemented in the fetch stage
//              (the PC register is not loaded when EBREAK is fetched).
//////////////////////////////////////////////////////////////////////////////////

module ControlUnit (
    input      [6:0] opcode,
    output reg       Branch,
    output reg       Jump,      // JAL
    output reg       JumpReg,   // JALR
    output reg       MemRead,
    output reg       MemWrite,
    output reg       ALUSrc,    // 1: immediate, 0: rs2
    output reg       RegWrite,
    output reg [1:0] ASel,      // 0: rs1, 1: PC (AUIPC), 2: zero (LUI)
    output reg [1:0] WBSel      // 0: ALU, 1: memory, 2: PC+4
);

    always @(*) begin
        Branch   = 1'b0;
        Jump     = 1'b0;
        JumpReg  = 1'b0;
        MemRead  = 1'b0;
        MemWrite = 1'b0;
        ALUSrc   = 1'b0;
        RegWrite = 1'b0;
        ASel     = 2'd0;
        WBSel    = 2'd0;

        case (opcode)
            7'b0110011: begin               // R-type (RV32I + RV32M)
                RegWrite = 1'b1;
            end
            7'b0010011: begin               // I-type ALU
                ALUSrc   = 1'b1;
                RegWrite = 1'b1;
            end
            7'b0000011: begin               // loads
                ALUSrc   = 1'b1;
                MemRead  = 1'b1;
                RegWrite = 1'b1;
                WBSel    = 2'd1;
            end
            7'b0100011: begin               // stores
                ALUSrc   = 1'b1;
                MemWrite = 1'b1;
            end
            7'b1100011: begin               // branches
                Branch   = 1'b1;
            end
            7'b1101111: begin               // JAL
                Jump     = 1'b1;
                RegWrite = 1'b1;
                WBSel    = 2'd2;
            end
            7'b1100111: begin               // JALR
                JumpReg  = 1'b1;
                ALUSrc   = 1'b1;
                RegWrite = 1'b1;
                WBSel    = 2'd2;
            end
            7'b0110111: begin               // LUI   (0 + imm)
                ALUSrc   = 1'b1;
                ASel     = 2'd2;
                RegWrite = 1'b1;
            end
            7'b0010111: begin               // AUIPC (PC + imm)
                ALUSrc   = 1'b1;
                ASel     = 2'd1;
                RegWrite = 1'b1;
            end
            // 7'b0001111 FENCE/FENCE.TSO/PAUSE and 7'b1110011 ECALL/EBREAK:
            // all signals stay 0 -> no-operation.
            default: begin
            end
        endcase
    end

endmodule
