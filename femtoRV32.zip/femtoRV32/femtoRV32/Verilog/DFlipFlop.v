`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Module Name: DFlipFlop
// Description: Positive-edge D flip-flop with asynchronous active-high reset.
//////////////////////////////////////////////////////////////////////////////////

module DFlipFlop (
    input      clk,
    input      rst,
    input      D,
    output reg Q
);

    always @(posedge clk or posedge rst) begin
        if (rst)
            Q <= 1'b0;
        else
            Q <= D;
    end

endmodule
