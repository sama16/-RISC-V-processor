`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Module Name: Four_Digit_Seven_Segment_Driver_Optimized
// Description: Shows a 13-bit unsigned number (0..8191) in decimal on the four
//              right-most digits of the Nexys A7 seven-segment display.
//              LED_out = {a, b, c, d, e, f, g}, active low.
//////////////////////////////////////////////////////////////////////////////////

module Four_Digit_Seven_Segment_Driver_Optimized (
    input             clk,
    input      [12:0] num,
    output reg [3:0]  Anode,
    output reg [6:0]  LED_out
);

    reg  [3:0]  LED_BCD;
    reg  [19:0] refresh_counter = 20'd0;
    wire [1:0]  LED_activating_counter;

    wire [3:0] Thousands, Hundreds, Tens, Ones;

    always @(posedge clk) begin
        refresh_counter <= refresh_counter + 1'b1;
    end

    assign LED_activating_counter = refresh_counter[19:18];

    BCD bcd (
        .num(num),
        .Thousands(Thousands),
        .Hundreds(Hundreds),
        .Tens(Tens),
        .Ones(Ones)
    );

    always @(*) begin
        case (LED_activating_counter)
            2'b00: begin Anode = 4'b0111; LED_BCD = Thousands; end
            2'b01: begin Anode = 4'b1011; LED_BCD = Hundreds;  end
            2'b10: begin Anode = 4'b1101; LED_BCD = Tens;      end
            2'b11: begin Anode = 4'b1110; LED_BCD = Ones;      end
            default: begin Anode = 4'b1111; LED_BCD = 4'b0000; end
        endcase
    end

    always @(*) begin
        case (LED_BCD)
            4'd0: LED_out = 7'b0000001;
            4'd1: LED_out = 7'b1001111;
            4'd2: LED_out = 7'b0010010;
            4'd3: LED_out = 7'b0000110;
            4'd4: LED_out = 7'b1001100;
            4'd5: LED_out = 7'b0100100;
            4'd6: LED_out = 7'b0100000;
            4'd7: LED_out = 7'b0001111;
            4'd8: LED_out = 7'b0000000;
            4'd9: LED_out = 7'b0000100;
            default: LED_out = 7'b1111111;
        endcase
    end

endmodule

//////////////////////////////////////////////////////////////////////////////////
// Module Name: BCD
// Description: 13-bit binary to 4-digit BCD (double dabble).
//////////////////////////////////////////////////////////////////////////////////
module BCD (
    input      [12:0] num,
    output reg [3:0]  Thousands,
    output reg [3:0]  Hundreds,
    output reg [3:0]  Tens,
    output reg [3:0]  Ones
);

    integer i;

    always @(*) begin
        Thousands = 4'd0;
        Hundreds  = 4'd0;
        Tens      = 4'd0;
        Ones      = 4'd0;

        for (i = 12; i >= 0; i = i - 1) begin
            if (Thousands >= 5) Thousands = Thousands + 4'd3;
            if (Hundreds  >= 5) Hundreds  = Hundreds  + 4'd3;
            if (Tens      >= 5) Tens      = Tens      + 4'd3;
            if (Ones      >= 5) Ones      = Ones      + 4'd3;

            Thousands    = Thousands << 1;
            Thousands[0] = Hundreds[3];
            Hundreds     = Hundreds << 1;
            Hundreds[0]  = Tens[3];
            Tens         = Tens << 1;
            Tens[0]      = Ones[3];
            Ones         = Ones << 1;
            Ones[0]      = num[i];
        end
    end

endmodule
