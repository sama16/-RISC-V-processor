`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Module Name: ImmGen
// Description: Immediate generator for all RV32I formats.
//              B- and J-type offsets are produced already multiplied by 2
//              (bit 0 = 0), so no separate shift-left is needed.
//////////////////////////////////////////////////////////////////////////////////

module ImmGen (
    input      [31:0] inst,
    output reg [31:0] gen_out
);

    always @(*) begin
        case (inst[6:0])
            // I-type: loads, immediate ALU operations, JALR
            7'b0000011,
            7'b0010011,
            7'b1100111:
                gen_out = {{20{inst[31]}}, inst[31:20]};

            // S-type: stores
            7'b0100011:
                gen_out = {{20{inst[31]}}, inst[31:25], inst[11:7]};

            // B-type: conditional branches
            7'b1100011:
                gen_out = {{19{inst[31]}}, inst[31], inst[7],
                           inst[30:25], inst[11:8], 1'b0};

            // U-type: LUI, AUIPC
            7'b0110111,
            7'b0010111:
                gen_out = {inst[31:12], 12'b0};

            // J-type: JAL
            7'b1101111:
                gen_out = {{11{inst[31]}}, inst[31], inst[19:12],
                           inst[20], inst[30:21], 1'b0};

            default:
                gen_out = 32'b0;
        endcase
    end

endmodule
