`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Module Name: N_bitRegister
// Description: N-bit register with load enable and asynchronous reset.
//              Used for the PC and for every pipeline register.
//////////////////////////////////////////////////////////////////////////////////

module N_bitRegister #(parameter N = 32) (
    input          clk,
    input          rst,
    input          load,
    input  [N-1:0] D,
    output [N-1:0] Q
);

    wire [N-1:0] mux_out;

    genvar i;
    generate
        for (i = 0; i < N; i = i + 1) begin : bit_cell
            multiplexer2to1 mux (
                .a(Q[i]),
                .b(D[i]),
                .sel(load),
                .out(mux_out[i])
            );

            DFlipFlop ff (
                .clk(clk),
                .rst(rst),
                .D(mux_out[i]),
                .Q(Q[i])
            );
        end
    endgenerate

endmodule
