`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Module Name: decoder5x32
// Description: 5-to-32 one-hot decoder with enable (register-file write select).
//////////////////////////////////////////////////////////////////////////////////

module decoder5x32 (
    input  [4:0]  in,
    input         enable,
    output [31:0] out
);

    assign out = enable ? (32'b1 << in) : 32'b0;

endmodule
